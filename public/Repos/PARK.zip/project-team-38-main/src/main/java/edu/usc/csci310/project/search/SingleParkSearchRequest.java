package edu.usc.csci310.project.search;

public class SingleParkSearchRequest {
    private String parkCode;

    public String getParkCode() {
        return parkCode;
    }

    public void setParkCode(String parkCode) {
        this.parkCode = parkCode;
    }
}

