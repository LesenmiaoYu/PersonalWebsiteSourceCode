import os
from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from .extensions import db
from .default import insert_default_managers, insert_default_locations

def create_app():
    app = Flask(__name__)
    CORS(app)

    MYSQL_USER = os.getenv('MYSQL_USER')
    MYSQL_PASSWORD = os.getenv('MYSQL_PASSWORD')
    MYSQL_HOST = os.getenv('MYSQL_HOST')
    MYSQL_PORT = os.getenv('MYSQL_PORT')
    MYSQL_DB = os.getenv('MYSQL_DB')
    MYSQL_SSL_MODE = os.getenv('MYSQL_SSL_MODE', 'DISABLED').upper()

    connection_string = f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}'
    app.config['SQLALCHEMY_DATABASE_URI'] = connection_string
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['JWT_SECRET_KEY'] = os.getenv('MYJWT_KEY')

    if MYSQL_SSL_MODE == 'REQUIRED':
        app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
            'connect_args': {
                'ssl': {'ssl_mode': 'REQUIRED'}
            }
        }

    db.init_app(app)

    jwt = JWTManager(app)
    from .route.public_routes import public_bp
    from .route.admin.admin_routes import admin_bp
    from .route.auth_routes import auth_bp
    from .route.player.player_routes import player_bp
    from .route.upload_routes import upload_bp
    app.register_blueprint(public_bp, url_prefix='/api')
    app.register_blueprint(auth_bp, url_prefix='/api')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    app.register_blueprint(player_bp, url_prefix='/api/player')
    app.register_blueprint(upload_bp, url_prefix='/api')
    with app.app_context():
        insert_default_locations(db)
        insert_default_managers(db)

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000)