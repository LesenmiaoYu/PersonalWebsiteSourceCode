from dataclasses import dataclass
from ..models import Room

@dataclass
class RoomDTO:
    id: int
    name: str

    @classmethod
    def from_model(cls, instance: Room):
        return cls(
            id=instance.id,
            name=instance.name,
        )
