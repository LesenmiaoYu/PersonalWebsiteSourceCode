from dataclasses import dataclass
from ..models import MessageFile

@dataclass
class MessageFileDTO:
    file_id: int
    message_id: int
    url: str

    @classmethod
    def from_model(cls, instance: MessageFile):
        return cls(
            file_id=instance.id,
            message_id=instance.message_id,
            url=instance.url
        )