from dataclasses import dataclass
from typing import List
from ..models import ScenarioDecisionMapping

@dataclass
class ScenarioDecisionMappingDTO:
    from_scenario: int
    to_scenario: int
    choice_id: int

    @classmethod
    def from_model(cls, mapping: ScenarioDecisionMapping):
        return cls(
            from_scenario=mapping.from_scenario,
            to_scenario=mapping.to_scenario,
            choice_id=mapping.choice_id
        )
