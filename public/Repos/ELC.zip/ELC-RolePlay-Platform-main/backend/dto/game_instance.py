from dataclasses import dataclass
from datetime import datetime
from ..models import GameInstance,Scenario,ScenarioChoice, ScenarioFile
from ..dto.scenario import ScenarioDTO
from ..dto.scenario_choice import ScenarioChoiceDTO
from ..dto.scenario_file import ScenarioFileDTO

@dataclass
class GameInstanceDTO:
    instance_id: int
    game_id: int
    location_id: int
    room_id: int
    scenario: ScenarioDTO
    state: str
    created_at: datetime
    started_at: datetime
    updated_at: datetime

    # The current gameInstance DTO have incomplete/repeating content but not affecting how it works.
    @classmethod
    def from_model(cls, instance: GameInstance, ):
        game_id = instance.game_id
        scenario_id = instance.scenario_id
        scenario = Scenario.query.get(scenario_id)
        
        # Parse the current scenario information into DTO
        choices = ScenarioChoice.query.filter_by(scenario_id=scenario.id).all()
        files = ScenarioFile.query.filter_by(scenario_id=scenario.id).all()
        scenario_dto = ScenarioDTO.from_model(
            scenario, 
            choices=[ScenarioChoiceDTO.from_model(c) for c in choices],  # Convert Choice models to DTO if needed
            files=[ScenarioFileDTO.from_model(sf) for sf in files]  # Convert File models to DTO if needed
        )     
        
        return cls(
            instance_id=instance.id,
            game_id=game_id,
            location_id=instance.location_id,
            room_id=instance.room_id,
            scenario=scenario_dto,
            state=instance.state,
            created_at=instance.created_at,
            started_at=instance.started_at,
            updated_at=instance.updated_at
        )
