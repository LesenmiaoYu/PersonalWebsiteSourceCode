from dataclasses import dataclass
from ..models import ScenarioChoice
@dataclass
class ScenarioChoiceDTO:
    id: int
    content: str

    @classmethod
    def from_model(cls, instance: ScenarioChoice):
        return cls(
            id=instance.id,
            content=instance.content
        )
