from dataclasses import dataclass
from ..models import ScenarioFile
@dataclass
class ScenarioFileDTO:
    id: int
    name: str
    url: str

    @classmethod
    def from_model(cls, instance: ScenarioFile):
        return cls(
            id=instance.id,
            name=instance.name,
            url=instance.url,
        )