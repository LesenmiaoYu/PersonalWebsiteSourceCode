from dataclasses import dataclass
from ..models import Location
@dataclass
class LocationDTO:
    id: int
    name: str
    @classmethod
    def from_model(cls, instance: Location):
        return cls(
            id=instance.id,
            name=instance.name
        )
