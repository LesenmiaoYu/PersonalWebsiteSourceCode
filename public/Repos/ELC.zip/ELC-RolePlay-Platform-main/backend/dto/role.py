from dataclasses import dataclass
from ..models import Role
@dataclass
class RoleDTO:
    id: int
    name: str
    mandatory: bool
    principal: bool

    @classmethod
    def from_model(cls, instance: Role):
        return cls(
            id=instance.id,
            name=instance.name,
            mandatory=instance.mandatory,
            principal=instance.principal
        )
