from dataclasses import dataclass
from datetime import datetime
from ..models import Message
from ..dto.message_file import MessageFileDTO

@dataclass
class MessageDTO:
    message_id: int
    content: str
    role_id: int
    files: list

    @classmethod
    def from_model(cls, message: Message, files: list):
        file_dtos = [MessageFileDTO.from_model(file) for file in files]
        return cls(
            message_id=message.id,
            content=message.content,
            role_id=message.role_id,
            files=file_dtos 
        )
