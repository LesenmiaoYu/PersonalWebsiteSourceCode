from dataclasses import dataclass, field
from typing import List
from ..models import Scenario
from ..dto.scenario_choice import ScenarioChoiceDTO
from ..dto.scenario_file import ScenarioFileDTO

@dataclass
class ScenarioDTO:
    id: int
    name: str
    first_scenario: bool
    number: int
    choices: List[ScenarioChoiceDTO] = field(default_factory=list)
    files: List[ScenarioFileDTO] = field(default_factory=list)
   

    @classmethod
    def from_model(cls, scenario: Scenario, choices: List[ScenarioChoiceDTO], files: List[ScenarioFileDTO]):
        return cls(
            id=scenario.id,
            name=scenario.name,
            first_scenario=scenario.first_scenario,
            choices=choices,
            files=files,
            number=scenario.number
        )
