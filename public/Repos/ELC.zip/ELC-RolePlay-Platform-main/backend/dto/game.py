from dataclasses import dataclass, field
from typing import List
from ..dto.role import RoleDTO
from ..dto.scenario import ScenarioDTO

@dataclass
class GameDTO:
    id: int
    name: str
    roles: List[RoleDTO] = field(default_factory=list)
    scenarios: List[ScenarioDTO] = field(default_factory=list)
    scenario_decision_mappings: List[dict] = field(default_factory=list)

    @classmethod
    def from_model(cls, game, roles, scenarios):
        return cls(
            id=game.id,
            name=game.name,
            roles=roles,
            scenarios=scenarios
        )
