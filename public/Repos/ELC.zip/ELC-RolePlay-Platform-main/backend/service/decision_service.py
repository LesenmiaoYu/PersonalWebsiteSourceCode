from ..models import Scenario, Role, ScenarioChoice, ScenarioDecision, ScenarioDecisionMapping
from ..extensions import db

def make_decision_service(instance_id, scenario_id, choice_id, role_id):
    # Check if the scenario is valid
    scenario = Scenario.query.get(scenario_id)
    if not scenario:
        return {"error": "Invalid scenario provided"}, 404

    # Check if the role is valid and is principal
    role = Role.query.get(role_id)
    if not role:
        return {"error": "Role not found"}, 404
    if not role.principal:
        return {"error": "Only principal roles can make decisions"}, 403

    # Check if the choice corresponds to the scenario
    valid_choice = ScenarioChoice.query.filter_by(scenario_id=scenario_id, id=choice_id).first()
    if not valid_choice:
        return {"error": "Invalid choice for the specified scenario"}, 400

    # Check if a decision already exists; if so, overwrite it
    existing_decision = ScenarioDecision.query.filter_by(instance_id=instance_id, scenario_id=scenario_id).first()
    if existing_decision:
        existing_decision.choice_id = choice_id  # Overwrite the choice
        message = "Decision updated successfully"
    else:
        # If no existing decision, create a new one
        decision = ScenarioDecision(instance_id=instance_id, scenario_id=scenario_id, choice_id=choice_id)
        db.session.add(decision)
        message = "Decision saved successfully"

    db.session.commit()

    return {"message": message}, 200
