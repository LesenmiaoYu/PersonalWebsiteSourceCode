from dataclasses import asdict
from ..extensions import db
from ..models.game import Game
from ..models.role import Role
from ..models.scenario import Scenario
from ..models.game_instance import GameInstance
from ..models.scenario_choice import ScenarioChoice
from ..models.scenario_decision_mapping import ScenarioDecisionMapping
from ..models.scenario_file import ScenarioFile
from ..dto.role import RoleDTO
from ..dto.game import GameDTO
from ..dto.scenario import ScenarioDTO
from ..dto.scenario_file import ScenarioFileDTO
from ..dto.scenario_choice import ScenarioChoiceDTO
from ..dto.scenario_mapping import ScenarioDecisionMappingDTO
from ..consts import GAME_INSTANCE_STATE_ONGOING


def create_game_service(game_data):
    try:
        game_name = game_data['name']
        new_game = Game(name=game_name)
        db.session.add(new_game)
        db.session.flush()  # creates new_game.id without committing

        # create roles
        roles_data = game_data.get('roles', [])
        roles = []
        has_principal = False
        for role_data in roles_data:
            role_name = role_data.get('name')
            mandatory = role_data.get('mandatory', False)
            principal = role_data.get('principal', False)
            if has_principal and principal:
                db.session.rollback()
                return {'message': 'Only 1 "principal" role is allowed'}, 400

            if not role_name:
                db.session.rollback()
                return {'message': 'Each role must have a "name"'}, 400
            role = Role(name=role_name, game_id=new_game.id, mandatory=mandatory, principal=principal)
            roles.append(role)
            db.session.add(role)

            if not has_principal:
                has_principal = principal

        if not has_principal:
            db.session.rollback()
            return {'message': 'Must have at least 1 "principal" role'}, 400
        # create scenarios
        scenarios_data = game_data.get('scenarios', [])
        scenarios = {}
        has_first_scenario = False
        for scenario_data in scenarios_data:
            scenario_name = scenario_data.get('name')
            scenario_number = scenario_data.get('scenario_number')
            first_scenario = scenario_data.get('first_scenario', False)
            if has_first_scenario and first_scenario:
                db.session.rollback()
                return {'message': 'Each game must have a one and only true "first_scenario"'}, 400
            if not has_first_scenario:
                has_first_scenario = first_scenario

            if not scenario_name or scenario_number is None:
                db.session.rollback()
                return {'message': 'Each scenario must have a "name" and "scenario_number"'}, 400
            scenario = Scenario(name=scenario_name, game_id=new_game.id, first_scenario=first_scenario, number=scenario_number)

            if scenario_number in scenarios:
                db.session.rollback()
                return {'message': 'Each scenario must have an unique "scenario_number"'}, 400
            scenarios[scenario_number] = scenario
            db.session.add(scenario)

        if not has_first_scenario:
            db.session.rollback()
            return {'message': 'Each scenario must have a "first_scenario"'}, 400
        db.session.flush()  # creates scenario IDs without committing

        # create scenario choices and files
        scenario_choices = {}
        for scenario_data in scenarios_data:
            scenario_number = scenario_data.get('scenario_number')
            choices_data = scenario_data.get('choices', [])
            scenario = scenarios[scenario_number]
            # create choices
            if choices_data:
                for choice_data in choices_data:
                    content = choice_data.get('content')
                    choice_number = choice_data.get('choice_number')
                    if not content or choice_number is None:
                        db.session.rollback()
                        return {'message': 'Each choice must have "content" and "choice_number"'}, 400
                    choice = ScenarioChoice(scenario_id=scenario.id, content=content)
                    if scenario_number not in scenario_choices:
                        scenario_choices[scenario_number] = {}
                    scenario_choices[scenario_number][choice_number] = choice
                    db.session.add(choice)
            # create scenario files
            scenario_files_data = scenario_data.get('scenario_files', [])
            if scenario_files_data:
                for scenario_file in scenario_files_data:
                    scenario_name = scenario_file.get('name')
                    url = scenario_file.get('url')
                    if scenario_name is None or url is None:
                        db.session.rollback()
                        return {'message': 'Each scenario file must have "name" and "url"'}, 400
                    scenario_file = ScenarioFile(name=scenario_name, url=url, scenario_id=scenario.id)
                    db.session.add(scenario_file)
        db.session.flush()  # creates choice IDs without committing

        scenario_id_map = {number: scenario.id for number, scenario in scenarios.items()}
        choice_id_map = {}
        for scenario_number, choices in scenario_choices.items():
            for choice_number, choice in choices.items():
                choice_id_map[(scenario_number, choice_number)] = choice.id

        # create scenario decision mappings
        scenario_decision_mappings_data = game_data.get('scenario_decision_mappings', [])
        for mapping_data in scenario_decision_mappings_data:
            from_scenario_number = mapping_data.get('from_scenario')
            to_scenario_number = mapping_data.get('to_scenario')
            choice_number = mapping_data.get('choice_number')
            if from_scenario_number is None or to_scenario_number is None:
                db.session.rollback()
                return {'message': 'Each mapping must have "from_scenario" and "to_scenario(s)"'}, 400
            from_scenario_id = scenario_id_map.get(from_scenario_number)
            to_scenario_id = scenario_id_map.get(to_scenario_number)
            if not from_scenario_id or not to_scenario_id:
                db.session.rollback()
                return {'message': 'Invalid scenario numbers in mappings'}, 400
            if choice_number:
                choice_id = choice_id_map.get((from_scenario_number, choice_number))
                if not choice_id:
                    db.session.rollback()
                    return {'message': 'Invalid choice number in mappings'}, 400
                mapping = ScenarioDecisionMapping(from_scenario=from_scenario_id, to_scenario=to_scenario_id,
                                                  choice_id=choice_id)
            else:
                mapping = ScenarioDecisionMapping(from_scenario=from_scenario_id, to_scenario=to_scenario_id,
                                                  choice_id=None)
            db.session.add(mapping)

        # Final commit
        try:
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            return {'message': 'An error occurred while saving data', 'error': e}, 500
        print("game done", new_game)
        return {'message': 'Game created successfully', 'game_id': new_game.id}, 201

    except Exception as e:
        db.session.rollback()
        return {'message': 'An error occurred while saving data', 'error': str(e)}, 500

def list_games_service():
    games = Game.query.all()
    game_dtos = []
    for game in games:
        roles = Role.query.filter_by(game_id=game.id).all()
        role_dtos = [RoleDTO.from_model(role) for role in roles]

        scenarios = Scenario.query.filter_by(game_id=game.id).all()
        scenario_dtos = []
        for scenario in scenarios:
            choices = ScenarioChoice.query.filter_by(scenario_id=scenario.id).all()
            choice_dtos = [ScenarioChoiceDTO.from_model(choice) for choice in choices]

            files = ScenarioFile.query.filter_by(scenario_id=scenario.id).all()
            file_dtos = [ScenarioFileDTO.from_model(file) for file in files]

            # Initialize ScenarioDTO
            scenario_dto = ScenarioDTO(
                id=scenario.id,
                name=scenario.name,
                number=scenario.number,
                first_scenario=scenario.first_scenario,
                choices=choice_dtos,
                files=file_dtos
            )
            scenario_dtos.append(scenario_dto)

            decision_mappings = ScenarioDecisionMapping.query.filter(
            ScenarioDecisionMapping.from_scenario.in_([s.id for s in scenarios])
        ).all()
        mapping_dtos = [
            {
                "from_scenario": mapping.from_scenario,
                "to_scenario": mapping.to_scenario,
                "choice_id": mapping.choice_id
            } for mapping in decision_mappings
        ]

        # Initialize GameDTO
        game_dto = GameDTO(
            id=game.id,
            name=game.name,
            roles=role_dtos,
            scenarios=scenario_dtos,
            scenario_decision_mappings=mapping_dtos
        )
        game_dtos.append(game_dto)

    return [asdict(game_dto) for game_dto in game_dtos]

def delete_game_service(game_id):
    try:
        # Fetch the game
        game = Game.query.get(game_id)
        if not game:
            return {'message': 'Game not found'}, 404
        
        GameInstance.query.filter_by(
            game_id=game.id,
            state=GAME_INSTANCE_STATE_ONGOING
        ).delete(synchronize_session='fetch')

        # # Delete scenario decision mappings
        # ScenarioDecisionMapping.query.filter(
        #     (ScenarioDecisionMapping.from_scenario.in_(Scenario.query.with_entities(Scenario.id).filter_by(game_id=game_id))) |
        #     (ScenarioDecisionMapping.to_scenario.in_(Scenario.query.with_entities(Scenario.id).filter_by(game_id=game_id)))
        # ).delete(synchronize_session='fetch')

        # # Delete scenario choices
        # ScenarioChoice.query.filter(ScenarioChoice.scenario_id.in_(
        #     Scenario.query.with_entities(Scenario.id).filter_by(game_id=game_id)
        # )).delete(synchronize_session='fetch')

        # # Delete scenario files
        # ScenarioFile.query.filter(ScenarioFile.scenario_id.in_(
        #     Scenario.query.with_entities(Scenario.id).filter_by(game_id=game_id)
        # )).delete(synchronize_session='fetch')

        # # Delete scenarios
        # Scenario.query.filter_by(game_id=game_id).delete()

        # # Delete roles
        # Role.query.filter_by(game_id=game_id).delete()

        # Delete the game itself
        db.session.delete(game)

        # Final commit
        db.session.commit()

        return {'message': 'Game and all associated data deleted successfully', 'game_id': game_id}, 200

    except Exception as e:
        db.session.rollback()
        return {'message': 'An error occurred while deleting data', 'error': str(e)}, 500


def edit_game_service(game_id, game_data):
    try:
        game = Game.query.get(game_id)
        if not game:
            return {'message': 'Game not found'}, 404

        game.name = game_data['name']
        db.session.flush()  # updates game without committing

        # Update roles
        Role.query.filter_by(game_id=game_id).delete()
        roles = []
        has_principal = False
        for role_data in game_data.get('roles', []):
            role_name = role_data.get('name')
            mandatory = role_data.get('mandatory', False)
            principal = role_data.get('principal', False)
            if has_principal and principal:
                db.session.rollback()
                return {'message': 'Only 1 "principal" role is allowed'}, 400

            if not role_name:
                db.session.rollback()
                return {'message': 'Each role must have a "name"'}, 400
            role = Role(name=role_name, game_id=game_id, mandatory=mandatory, principal=principal)
            roles.append(role)
            db.session.add(role)

            if not has_principal:
                has_principal = principal

        if not has_principal:
            db.session.rollback()
            return {'message': 'Must have at least 1 "principal" role'}, 400

        # Update scenarios
        Scenario.query.filter_by(game_id=game_id).delete()
        scenarios = {}
        has_first_scenario = False
        for scenario_data in game_data.get('scenarios', []):
            scenario_name = scenario_data.get('name')
            scenario_number = scenario_data.get('scenario_number')
            first_scenario = scenario_data.get('first_scenario', False)
            if has_first_scenario and first_scenario:
                db.session.rollback()
                return {'message': 'Each game must have a one and only true "first_scenario"'}, 400
            if not has_first_scenario:
                has_first_scenario = first_scenario

            if not scenario_name or scenario_number is None:
                db.session.rollback()
                return {'message': 'Each scenario must have a "name" and "scenario_number"'}, 400
            scenario = Scenario(name=scenario_name, game_id=game_id, first_scenario=first_scenario)

            if scenario_number in scenarios:
                db.session.rollback()
                return {'message': 'Each scenario must have an unique "scenario_number"'}, 400
            scenarios[scenario_number] = scenario
            db.session.add(scenario)

        if not has_first_scenario:
            db.session.rollback()
            return {'message': 'Each scenario must have a "first_scenario"'}, 400
        db.session.flush()  # creates scenario IDs without committing

        # Update scenario choices and files
        scenario_choices = {}
        for scenario_data in game_data.get('scenarios', []):
            scenario_number = scenario_data.get('scenario_number')
            choices_data = scenario_data.get('choices', [])
            scenario = scenarios[scenario_number]
            # create choices
            if choices_data:
                for choice_data in choices_data:
                    content = choice_data.get('content')
                    choice_number = choice_data.get('choice_number')
                    if not content or choice_number is None:
                        db.session.rollback()
                        return {'message': 'Each choice must have "content" and "choice_number"'}, 400
                    choice = ScenarioChoice(scenario_id=scenario.id, content=content)
                    if scenario_number not in scenario_choices:
                        scenario_choices[scenario_number] = {}
                    scenario_choices[scenario_number][choice_number] = choice
                    db.session.add(choice)
            # create scenario files
            scenario_files_data = scenario_data.get('scenario_files', [])
            if scenario_files_data:
                for scenario_file in scenario_files_data:
                    scenario_name = scenario_file.get('name')
                    url = scenario_file.get('url')
                    if scenario_name is None or url is None:
                        db.session.rollback()
                        return {'message': 'Each scenario file must have "name" and "url"'}, 400
                    scenario_file = ScenarioFile(name=scenario_name, url=url, scenario_id=scenario.id)
                    db.session.add(scenario_file)
        db.session.flush()  # creates choice IDs without committing

        scenario_id_map = {number: scenario.id for number, scenario in scenarios.items()}
        choice_id_map = {}
        for scenario_number, choices in scenario_choices.items():
            for choice_number, choice in choices.items():
                choice_id_map[(scenario_number, choice_number)] = choice.id

        # Update scenario decision mappings
        ScenarioDecisionMapping.query.filter_by(game_id=game_id).delete()
        for mapping_data in game_data.get('scenario_decision_mappings', []):
            from_scenario_number = mapping_data.get('from_scenario')
            to_scenario_number = mapping_data.get('to_scenario')
            choice_number = mapping_data.get('choice_number')
            if from_scenario_number is None or to_scenario_number is None:
                db.session.rollback()
                return {'message': 'Each mapping must have "from_scenario" and "to_scenario(s)"'}, 400
            from_scenario_id = scenario_id_map.get(from_scenario_number)
            to_scenario_id = scenario_id_map.get(to_scenario_number)
            if not from_scenario_id or not to_scenario_id:
                db.session.rollback()
                return {'message': 'Invalid scenario numbers in mappings'}, 400
            if choice_number:
                choice_id = choice_id_map.get((from_scenario_number, choice_number))
                if not choice_id:
                    db.session.rollback()
                    return {'message': 'Invalid choice number in mappings'}, 400
                mapping = ScenarioDecisionMapping(from_scenario=from_scenario_id, to_scenario=to_scenario_id,
                                                  choice_id=choice_id)
            else:
                mapping = ScenarioDecisionMapping(from_scenario=from_scenario_id, to_scenario=to_scenario_id,
                                                  choice_id=None)
            db.session.add(mapping)

        # Final commit
        try:
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            return {'message': 'An error occurred while saving data', 'error': str(e)}, 500
        
        return {'message': 'Game updated successfully', 'game_id': game_id}, 200

    except Exception as e:
        db.session.rollback()
        return {'message': 'An error occurred while updating the game', 'error': str(e)}, 500


