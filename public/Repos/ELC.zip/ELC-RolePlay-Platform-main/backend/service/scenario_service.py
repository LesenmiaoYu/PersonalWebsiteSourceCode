from ..models.game_instance import GameInstance
from ..models.scenario import Scenario
from ..models.scenario_file import ScenarioFile
from ..models.scenario_choice import ScenarioChoice
from ..models.role import Role

def fetch_scenario_details(instance_id, role_id):
    # Fetch the game instance
    game_instance = GameInstance.query.get(instance_id)
    if not game_instance:
        return None, {'error': 'Game instance not found', 'code': 404}

    # Fetch the scenario
    scenario = Scenario.query.get(game_instance.scenario_id)
    if not scenario:
        return None, {'error': 'Scenario not found', 'code': 404}

    # Fetch scenario files
    scenario_files = ScenarioFile.query.filter_by(scenario_id=scenario.id).all()
    files_list = [{'name': file.name, 'url': file.url} for file in scenario_files]

    # Fetch and validate role
    role = Role.query.get(role_id)
    if not role:
        return None, {'error': 'Role not found', 'code': 404}

    # Base response with scenario and files
    response = {
        "data": {
            "scenario": {
                "id": scenario.id,
                "name": scenario.name,
                "game_id": game_instance.game_id,
                "scenario_files": files_list,
                "scenario_choices": []
            },
            "is_principal": False
        },
        "code": 200
    }

    # Check if the role is crucial, if so, include scenario_choices in the data.
    if role.principal:  # Ensure 'principal' is correct in the database model
        scenario_choices = ScenarioChoice.query.filter_by(scenario_id=scenario.id).all()
        choices_list = [{'choice_id': choice.id, 'content': choice.content} for choice in scenario_choices]
        response['data']['scenario']['scenario_choices'] = choices_list
        response['data']["is_principal"] = True

    return response, None
