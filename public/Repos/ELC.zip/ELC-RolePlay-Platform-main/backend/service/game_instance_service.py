from flask import jsonify
from datetime import datetime, timedelta
from dataclasses import asdict
from sqlalchemy.exc import SQLAlchemyError
from ..extensions import db
from ..models import Room, Location, Game, Scenario, GameInstance, ScenarioChoice, ScenarioDecision, Role, RoleInstance, InstanceStatus, ScenarioDecisionMapping
from ..dto.game_instance import GameInstanceDTO
from ..dto.role import RoleDTO
from ..consts import *

def create_game_instance_service(data):
    game_id = data['game_id']
    location_id = data['location_id']
    room_id = data['room_id']

    # Validate Game, Room and Location
    game = Game.query.filter_by(id=game_id).first()
    if not game:
        return {'message': 'invalid "game_id".'}, 400
    room = Room.query.filter_by(id=room_id).first()
    if not room:
        return {'message': 'invalid "room_id".'}, 400
    location = Location.query.filter_by(id=location_id).first()
    if not location:
        return {'message': 'invalid "location_id".'}, 400

    # Fetch first scenario
    first_scenario = Scenario.query.filter_by(game_id=game_id, first_scenario=True).first()
    if not first_scenario:
        return {'message': 'no available first_scenario -- check game setting'}, 500

    # Check if there's existing, duplicating instance that's created/ongoing
    existing_instance = GameInstance.query.filter(
        GameInstance.game_id == game_id,
        GameInstance.location_id == location_id,
        GameInstance.room_id == room_id,
        GameInstance.state.in_([GAME_INSTANCE_STATE_CREATED, GAME_INSTANCE_STATE_ONGOING])
    ).first()

    if existing_instance:
        return {'message': 'A game instance with the same game_id, location_id, and room_id is already in progress.'}, 400

    new_instance = GameInstance(
        game_id=game_id,
        location_id=location_id,
        room_id=room_id,
        scenario_id=first_scenario.id,
        state=GAME_INSTANCE_STATE_ONGOING,
        created_at=datetime.utcnow()
    )
    

    try:
        db.session.add(new_instance)
        # Get the new_instance ID before committing
        db.session.flush()  
        new_instance_status = InstanceStatus(
            instance_id=new_instance.id,
            current_scenario_id=first_scenario.id,
            next_scenario_id=None
        )
        db.session.add(new_instance_status)
        # Commit Transaction
        db.session.commit()
        
    except SQLAlchemyError as e:
        db.session.rollback()
        return {'message': 'Database error occurred while creating the game instance.'}, 500

    instance_dto = GameInstanceDTO.from_model(new_instance)
    return {'message': 'Game instance created successfully', 'game_instance': asdict(instance_dto)}, 201


def update_game_instance_state_service(instance_id, new_state):
    instance = GameInstance.query.get(instance_id)
    if not instance:
        return {'message': 'Game instance not found'}, 404
    valid_states=[GAME_INSTANCE_STATE_CREATED, GAME_INSTANCE_STATE_ONGOING, GAME_INSTANCE_STATE_TERMINATED]
    if new_state not in valid_states:
        return {'message': 'Not a valid state'}, 400
    instance.state = new_state
    instance.updated_at = datetime.utcnow()
    if new_state == GAME_INSTANCE_STATE_ONGOING:
        instance.started_at = instance.updated_at

    try:
        db.session.commit()
    except SQLAlchemyError as e:
        db.session.rollback()
        return {'message': 'Database error occurred while updating the game instance.'}, 500

    instance_dto = GameInstanceDTO.from_model(instance)
    return {'message': 'Game instance state updated successfully', 'game_instance': instance_dto}, 200

def get_game_instances_service(game_id=None, location_id=None, state=None):
    try:
        query = GameInstance.query
        
        # Apply filter if exist
        if game_id:
            query = query.filter_by(game_id=game_id)
        if location_id:
            query = query.filter_by(location_id=location_id)
        if state:
            query = query.filter_by(state=state)

        instances = query.all()
        
        # Collect related data for DTO conversion
        game_ids = {instance.game_id for instance in instances}
        scenario_ids = {instance.scenario_id for instance in instances}
        location_ids = {instance.location_id for instance in instances}
        room_ids = {instance.room_id for instance in instances}

        games = Game.query.filter(Game.id.in_(game_ids)).all()
        games_dict = {game.id: game for game in games}

        scenarios = Scenario.query.filter(Scenario.id.in_(scenario_ids)).all()
        scenarios_dict = {scenario.id: scenario for scenario in scenarios}

        locations = Location.query.filter(Location.id.in_(location_ids)).all()
        locations_dict = {location.id: location for location in locations}

        rooms = Room.query.filter(Room.id.in_(room_ids)).all()
        rooms_dict = {room.id: room for room in rooms}

        # Building DTOs
        instance_dtos = []
        for instance in instances:
            game = games_dict.get(instance.game_id)
            location = locations_dict.get(instance.location_id)
            room = rooms_dict.get(instance.room_id)
            scenario = scenarios_dict.get(instance.scenario_id)

            # Skip instances with missing data
            if not game or not location or not room or not scenario:
                continue

            instance_dto = GameInstanceDTO.from_model(instance)
            instance_dtos.append(instance_dto)

        return {'game_instances': instance_dtos}, 200

    except SQLAlchemyError:
        return {'message': 'Database error occurred while fetching game instances.'}, 500


def check_game_instances_status():
    try:
        ongoing_instances = GameInstance.query.filter_by(state=GAME_INSTANCE_STATE_ONGOING).all()
        instance_status_list = []

        for instance in ongoing_instances:
            # First verify that all required records exist
            scenario = Scenario.query.get(instance.scenario_id)
            if not scenario:
                continue  # Skip this instance or return error
                # return {"error": f"Instance {instance.id} doesn't have a valid scenario"}, 400

            game = Game.query.get(instance.game_id)
            if not game:
                continue  # Skip this instance or return error
                # return {"error": f"Instance {instance.id} doesn't have a valid game"}, 400

            location = Location.query.get(instance.location_id)
            room = Room.query.get(instance.room_id)
            
            # Retrieve all selected Roles information and put in response as DTO
            selected_roles = []
            role_instances = (
                db.session.query(Role)
                .select_from(Role)
                .join(RoleInstance, RoleInstance.role_id == Role.id)
                .filter(RoleInstance.instance_id == instance.id).all()
            )
            selected_roles = [RoleDTO.from_model(role) for role in role_instances]

            is_ready = False
            is_roles_selected = False
            is_decision_made = True
            decision_made = ""

            # Check all the mandatory roles and principal roles
            required_roles = Role.query.filter(
                Role.game_id == instance.game_id,
                db.or_(Role.mandatory == True, Role.principal == True)
            ).all()
            selected_roles_ids = {role.id for role in role_instances}
            is_roles_selected = all(role.id in selected_roles_ids for role in required_roles)

            # Check if this is the decision making round
            # If it is, check if a decision has been made
            decision_making_required = ScenarioChoice.query.filter_by(scenario_id=scenario.id).first() is not None
            if decision_making_required:
                is_decision_made = False
                decision = ScenarioDecision.query.filter_by(
                    instance_id=instance.id, 
                    scenario_id=scenario.id
                ).first()
                # Check decision's validity
                if decision:
                    choice = ScenarioChoice.query.get(decision.choice_id)
                    if choice:
                        is_decision_made = True
                        decision_made = choice.content
            
            # An intance is considered to be 'ready' if:
            # 1. All the mandatory and principal roles are selected by players
            # 2. If it's not a decision making round
            # 3. It's a decision making round and decision is made.
            is_ready = is_roles_selected and is_decision_made
            
            # Safely create status dictionary with fallback values
            instance_status = {
                "instance_id": instance.id,
                "game_name": game.name if game else "Unknown",
                "location": location.name if location else "Unknown",
                "room": room.name if room else "Unknown",
                "current_scenario_name": scenario.name,
                "roles_in_game": selected_roles,
                "is_decision_round": decision_making_required,
                "decision_made": decision_made if decision_made else "No decision yet",
                "is_ready": is_ready
            }

            instance_status_list.append(instance_status)

        return {"data": {"instances": instance_status_list}}, 200

    except Exception as e:
        print(f"Error in check_game_instances_status: {str(e)}")  # Add logging
        return {"error": str(e)}, 500
    
    
def proceed_game_instance_service(instance_id):
    instance_status = InstanceStatus.query.filter_by(instance_id=instance_id).first()
    if not instance_status:
        return {"error": "Instance status not found"}, 404
    
     # Fetch the current scenario ID and decision made
    current_scenario_id = instance_status.current_scenario_id
    # Check if the current scenario has choices
    scenario_has_choices = ScenarioChoice.query.filter_by(scenario_id=current_scenario_id).first() is not None
    decision = ScenarioDecision.query.filter_by(instance_id=instance_id, scenario_id=current_scenario_id).first()
    if scenario_has_choices and not decision:
        return {"error": "No decision made for the current scenario"}, 400
    
    if not scenario_has_choices:
        mapping = ScenarioDecisionMapping.query.filter_by(
            from_scenario=current_scenario_id,
            choice_id=None
        ).first()
    else:
        mapping = ScenarioDecisionMapping.query.filter_by(
            from_scenario=current_scenario_id,
            choice_id=decision.choice_id
        ).first()
        
    if not mapping:
        instance=GameInstance.query.get(instance_id)
        instance.state=GAME_INSTANCE_STATE_TERMINATED
        instance_status.next_scenario_id = -1
        db.session.commit()
        return {
            "message": "Game instance terminated - reached final scenario",
            "current_scenario_id": None,
            "final_state": "TERMINATED"
        }, 200
    
    instance_status.next_scenario_id = mapping.to_scenario
    db.session.commit()

    return {
        "message": "Game instance proceeded successfully",
        "current_scenario_id": current_scenario_id,
        "next_scenario_id": mapping.to_scenario
    }, 200
    

def get_terminated_instances_service(time_span):
    """
    Get all terminated instances and their scenario routes within the specified time span.
    
    Args:
        time_span (int): Number of hours to look back
        
    Returns:
        dict: Nested dictionary of games and their terminated instances with scenario routes
    """
    # Validate time_span
    if not isinstance(time_span, int):
        raise ValueError("Time span must be an integer")
    if time_span <= 0:
        raise ValueError("Time span must be positive")
    # if time_span > 168:  # 168 hours = 1 week
    #     raise ValueError("Time span cannot exceed 168 hours (1 week)")
    
    # Calculate the cutoff time
    cutoff_time = datetime.utcnow() - timedelta(hours=time_span)
    
    # Query terminated instances within time span
    terminated_instances = (
        GameInstance.query
        .filter(
            db.and_
            (
                GameInstance.state == GAME_INSTANCE_STATE_TERMINATED,
                GameInstance.created_at >= cutoff_time
            )
        ).all()
    )
    
    # Group instances by game
    games_dict = {}
    for instance in terminated_instances:
        scenario_route = []
        
        # Find the first scenario of the game
        first_scenario = Scenario.query.filter_by(
            game_id = instance.game_id,
            first_scenario = True
        ).first()
        # Using something similar to DFS to find the route based on:
        # 1. If it's not a decision_making scenario, check mapping and move 'cur_secnario' to the next
        # 2. If it's a decision_making scenario, check the choice this instance make
        cur_scenario = first_scenario
        while cur_scenario:
            scenario_route.append(cur_scenario.number)
            decision_making_required = ScenarioChoice.query.filter_by(
                scenario_id=cur_scenario.id
            ).first() is not None
            if not decision_making_required:
                mapping = ScenarioDecisionMapping.query.filter_by(
                    from_scenario=cur_scenario.id
                ).first()
                if mapping:
                    cur_scenario = Scenario.query.get(mapping.to_scenario)
                else:
                    cur_scenario = None
            else:
                decision_made = ScenarioDecision.query.filter(
                    db.and_(
                        ScenarioDecision.scenario_id == cur_scenario.id,
                        ScenarioDecision.instance_id == instance.id
                    )
                ).first()  # Added .first() since we expect one decision
                
                if decision_made:
                    scenario_mapping = ScenarioDecisionMapping.query.filter_by(
                        choice_id=decision_made.choice_id
                    ).first()
                    if scenario_mapping:
                        cur_scenario = Scenario.query.get(scenario_mapping.to_scenario)
                    else:
                        cur_scenario = None
                else:
                    cur_scenario = None
        
        # Add to games dictionary
        if instance.game_id not in games_dict:
            games_dict[instance.game_id] = {
                'game_id': instance.game_id,
                'game_name': Game.query.get(instance.game_id).name,
                'instances': []
            }
            
        games_dict[instance.game_id]['instances'].append({
            'instance_id': instance.id,
            'scenario_route': scenario_route,
            'location_name': Location.query.get(instance.location_id).name,
            'room_name': Room.query.get(instance.room_id).name
        })
    
    # Format response
    return {
        'games': list(games_dict.values())
    }