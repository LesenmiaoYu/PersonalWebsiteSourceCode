from ..models.instance_status import InstanceStatus 
from ..models.game_instance import GameInstance
from ..extensions import db

# Function to check instance status and proceed if possible
def check_and_proceed_instance_status(instance_id):
    instance_status = InstanceStatus.query.filter_by(instance_id=instance_id).first()
    if not instance_status:
        return None, {'error': 'Instance status not found', 'code': 404}
    # if the next_scenario_id is null, it's not ready for proceeding to the next game.
    if not instance_status.next_scenario_id:
        return {'data': {'is_ready': False, 'game_over': False}, 'code': 200}, None
    if instance_status.next_scenario_id == -1:
        return {'data': {'is_ready': False, 'game_over': True}}, None
    
    next_scenario_id = instance_status.next_scenario_id
    game_instance = GameInstance.query.filter_by(id=instance_id).first()
    
    # Otherwise, when the instance is ready to proceed, update the instance status table and gameInstance table
    instance_status.current_scenario_id = next_scenario_id
    instance_status.next_scenario_id = None  # Reset next_scenario_id to null after proceeding
    game_instance.scenario_id = next_scenario_id
    db.session.commit()
    
    return {'data': {'is_ready': True, 'game_over': False}, 'code': 200}, None