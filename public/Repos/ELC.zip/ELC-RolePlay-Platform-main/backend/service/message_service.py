from dataclasses import asdict
from ..extensions import db
from ..models.game import Game
from ..models.game_instance import GameInstance
from ..models import Message, MessageFile, Role
from ..dto.message import MessageDTO, MessageFileDTO


def create_message_service(content, instance_id=None, message_file=None, role_id=None):
    """
    Service to create messages. 
    If game_instance_id is None, create messages for all ongoing instances.
    If role_id is None, create messages for all the roles of the instance.
    """
    try:
        if instance_id is None:
            ongoing_instances = GameInstance.query.filter_by(state='ongoing').all()
            if not ongoing_instances:
                return {'message': 'No ongoing instances found.'}, 400
        else:
            # Validate provided game_instance_id
            game_instance = GameInstance.query.filter_by(id=instance_id).first()
            if not game_instance:
                return {'message': 'Invalid game_instance_id. Either not a running instance or not exist'}, 400
            ongoing_instances = [game_instance]
            
        for instance in ongoing_instances:
            new_message = Message(
                game_instance_id=instance.id,
                content=content,
                role_id=role_id  # Specific role or None
            )
            db.session.add(new_message) 
            db.session.flush()  # Get message_id before committing
            
            # if there's a valid url passed in, create associated message file
            if message_file:
                new_file = MessageFile(
                    message_id=new_message.id,
                    url=message_file
                )
                db.session.add(new_file) 
        db.session.commit()
        return {"message": "Messages created successfully for all specified rooms and roles."}, 201
            
    except Exception as e:
        db.session.rollback()
        print(f"Error occurred: {e}")
        return {'error': 'Database error occurred while creating messages.'}, 500



def get_message_service(instance_id, role_id):
    try:
        query = Message.query.filter(Message.game_instance_id == instance_id)
        query = query.filter((Message.role_id == role_id) | (Message.role_id.is_(None))) 
        # Execute the query
        messages = query.all()
        
        message_list = []
        for message in messages:
            files = MessageFile.query.filter_by(message_id=message.id).all()
            
            message_dto = MessageDTO.from_model(message, files) 
            message_dto.role_id = role_id
            message_list.append(message_dto)
        
        return {"data": {"messages": message_list}}, 200 
    
    except Exception as e:  
        print(f"Error fetching messages: {e}")
        return {"error": "An error occurred while fetching messages."}, 500