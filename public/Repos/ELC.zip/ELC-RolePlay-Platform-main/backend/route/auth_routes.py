from cryptography.fernet import Fernet
import os
import hashlib
import base64
from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token
from ..models import Manager

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    if not request.is_json:
        return jsonify({"msg": "Missing JSON in request"}), 400

    user_id = request.json.get('id', None)
    password = request.json.get('pw', None)

    if not user_id or not password:
        return jsonify({"msg": "Missing user ID or password"}), 400

    user = Manager.query.filter_by(id=user_id).first()
    if not user or not check_password_hash(user.pw, password):
        return jsonify({"msg": "Bad user ID or password"}), 401

    access_token = create_access_token(identity=user_id, expires_delta=False)
    return jsonify(access_token=access_token), 200
def check_password_hash(pw: str, input_pw: str) -> bool:
    key = os.getenv('ENCRYPTION_KEY')
    if not key:
        raise ValueError('ENCRYPTION_KEY environment variable not set')
    hash = hashlib.sha256(key.encode()).digest()
    fernet_key = base64.urlsafe_b64encode(hash)
    fernet = Fernet(fernet_key)

    decrypted_password = fernet.decrypt(pw).decode()

    return input_pw == decrypted_password