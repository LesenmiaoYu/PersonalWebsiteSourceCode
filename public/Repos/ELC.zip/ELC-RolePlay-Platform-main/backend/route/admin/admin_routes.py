from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from dataclasses import asdict
from ...service.game_service import create_game_service, list_games_service, delete_game_service, edit_game_service
from ...service.game_instance_service import create_game_instance_service, get_game_instances_service, check_game_instances_status, update_game_instance_state_service, proceed_game_instance_service, get_terminated_instances_service
from ...service.message_service import create_message_service
from ...consts import *

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard', methods=['GET'])
@jwt_required()
def admin_dashboard():
    current_user = get_jwt_identity()
    return jsonify(message=f'Welcome to the admin dashboard, {current_user}!')

@admin_bp.route('/games', methods=['POST'])
@jwt_required()
def create_game():
    if not request.is_json:
        return jsonify({'message': 'Request must be JSON'}), 400

    data = request.get_json()
    if 'game' not in data:
        return jsonify({'message': 'Missing "game" data in request'}), 400

    game_data = data['game']
    response, status_code = create_game_service(game_data)
    print("response", response)
    return jsonify(response), status_code

@admin_bp.route('/games', methods=['PUT'])
@jwt_required()
def edit_game():
    if not request.is_json:
        return jsonify({'message': 'Request must be JSON'}), 400

    data = request.get_json()
    if 'game' not in data or 'game_id' not in data:
        return jsonify({'message': 'Missing "game" or "game_id" data in request'}), 400

    game_id = data['game_id']
    game_data = data['game']
    response, status_code = edit_game_service(game_id, game_data)
    print("response", response)
    return jsonify(response), status_code


@admin_bp.route('/games', methods=['DELETE'])
@jwt_required()
def delete_game():
    if not request.is_json:
        return jsonify({'message': 'Request must be JSON'}), 400

    data = request.get_json()
    if 'game_id' not in data:
        return jsonify({'message': 'Missing "game_id" in request body'}), 400

    game_id = data['game_id']
    response, status_code = delete_game_service(game_id)
    return jsonify(response), status_code


@admin_bp.route('/games', methods=['GET'])
@jwt_required()
def list_games():
    game_dtos = list_games_service()
    return jsonify({'games': game_dtos}), 200

@admin_bp.route('/game-instances', methods=['POST'])
@jwt_required()
def create_game_instance():
    data = request.get_json()
    required_fields = ['game_id', 'location_id', 'room_id']

    for field in required_fields:
        if field not in data:
            return jsonify({'message': f'Missing required field: {field}'}), 400
    response, status_code = create_game_instance_service(data)
    return jsonify(response), status_code

@admin_bp.route('/game-instances/monitor', methods=['POST'])
@jwt_required()
def get_game_instances():
    data = request.get_json()
    game_id = data.get('game_id')
    location_id = data.get('location_id')
    state = data.get('state')
    
    response, status_code = get_game_instances_service(game_id=game_id, location_id=location_id, state=state)
    return jsonify(response), status_code


@admin_bp.route('/message', methods=['POST'])
@jwt_required()
def send_message():
    if not request.is_json:
        return jsonify({'message': 'Request must be JSON'}), 400

    data = request.get_json()
    content = data.get('content')
    instance_id = data.get('instance_id') # Optional instance_id
    role_id = data.get('role_id')  # Optional role_id
    message_file = data.get('file_url')

    if not content:
        return jsonify({'message': 'Missing required field: content'}), 400

    response, status_code = create_message_service( content, instance_id, message_file, role_id)
    return jsonify(response), status_code


@admin_bp.route('/game-instance/<int:instance_id>/state', methods=['PUT'])
@jwt_required()
def update_game_instance_state(instance_id):
    data = request.get_json()
    new_state = data.get('state')
    response, code = update_game_instance_state_service(instance_id, new_state)
    return jsonify(response), code


@admin_bp.route('/game-instances/check', methods=['GET'])
@jwt_required()
def check_game_instances():
    response, status_code = check_game_instances_status()
    return jsonify(response), status_code


@admin_bp.route('/game-instance/<int:instance_id>/proceed', methods=['POST'])
@jwt_required()
def proceed_game_instance(instance_id):
    response, status_code = proceed_game_instance_service(instance_id)
    return jsonify(response), status_code


@admin_bp.route('/game-instances/terminated/<int:time_span>', methods=['GET'])
@jwt_required()
def get_terminated_instances(time_span):
    """Get terminated instances and their scenario routes within specified time span."""
    try:
        result = get_terminated_instances_service(time_span)
        return {'data': result}, 200
    except Exception as e:
        return {'error': str(e)}, 500