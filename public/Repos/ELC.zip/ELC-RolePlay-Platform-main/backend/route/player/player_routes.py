from flask import Blueprint, request, jsonify
from dataclasses import asdict
from ...service.instance_status_service import check_and_proceed_instance_status
from ...service.scenario_service import fetch_scenario_details
from ...service.message_service import get_message_service
from ...service.decision_service import make_decision_service
from ...models.game_instance import GameInstance 
from ...models.game import Game
from ...models.role import Role
from ...models.scenario import Scenario
from ...models.location import Location
from ...models.room import Room
from ...models.role_instance import RoleInstance
from ...models.scenario_choice import ScenarioChoice
from ...models.scenario_decision import ScenarioDecision
from ...models.scenario_decision_mapping import ScenarioDecisionMapping
from ...dto.game_instance import GameInstanceDTO
from ...dto.game import GameDTO
from ...dto.role import RoleDTO
from ...extensions import db
from ...consts import GAME_INSTANCE_STATE_ONGOING

player_bp = Blueprint('/player', __name__)

@player_bp.route('/instances', methods=['GET'])
def get_instances():
    # Fetch all ongoing instances for player to select
    game_instances = GameInstance.query.filter_by(state='ongoing').all()
    # Convert each instance to DTO format
    instances_list = []
    
    for instance in game_instances:
        instance_dto = GameInstanceDTO.from_model(instance)
        instances_list.append(asdict(instance_dto))
        
    # Return the JSON response
    return jsonify({"data": {"ongoing_instances": instances_list}}), 200


@player_bp.route('/instance/<int:instance_id>/roles', methods=['GET'])
def get_roles(instance_id):
    # Logic to fetch roles for the specified game instance
    instance = GameInstance.query.get(instance_id)
    if not instance:
        return jsonify({'error': 'Game instance not found'}), 404
    
    game = Game.query.get(instance.game_id)
    if not game:
        return jsonify({'error': 'Game not found'}), 404
    
    roles = Role.query.filter_by(game_id=game.id).all()
    role_dtos = []
    for role in roles:
        role_dto = RoleDTO(
            id = role.id,
            name = role.name,
            mandatory= role.mandatory,
            principal= role.principal
        )
        role_dtos.append(asdict(role_dto))
    return jsonify(role_dtos), 200


@player_bp.route('/instance/<int:instance_id>/roles/check', methods=['GET'])
def check_instance_role(instance_id):
    # Fetch the instance and verify it exists
    instance = GameInstance.query.get(instance_id)
    if not instance:
        return jsonify({"error": "Instance not found"}), 404
    if instance.state != GAME_INSTANCE_STATE_ONGOING:
        return jsonify({"error": "Game instance not on-going"}), 400

    # Fetch selected roles for the instance
    selected_roles = RoleInstance.query.filter_by(instance_id=instance_id).all()
    selected_role_ids = {role_instance.role_id for role_instance in selected_roles}

    # Fetch available roles
    available_roles = Role.query.filter(~Role.id.in_(selected_role_ids), Role.game_id == instance.game_id).all()
    available_roles_dto = [RoleDTO.from_model(role) for role in available_roles]

    return jsonify({"data": {"available_roles": [asdict(role) for role in available_roles_dto]}}), 200


@player_bp.route('/instance/<int:instance_id>/role/<int:role_id>', methods=['POST'])
def select_role(instance_id, role_id):
    instance = GameInstance.query.get(instance_id)
    if not instance:
        return jsonify({'error': 'Game instance not found'}), 404
    # Only allow select role for on-going game_instance
    if instance.state != GAME_INSTANCE_STATE_ONGOING:
        return jsonify({'error': 'Game instance is either not started or terminated'}), 400
    
    # If no instance-role entry, role is valid for selection.
    role_instance = RoleInstance.query.filter_by(instance_id=instance_id, role_id=role_id).first()
    if role_instance:
        return jsonify({"message":"Role already selected, try another role."}), 400
    
    new_role_instance = RoleInstance(instance_id=instance_id, role_id=role_id)
    db.session.add(new_role_instance)
    db.session.commit()

    return jsonify({'message': 'Role selected successfully'}), 200


@player_bp.route('/instance/<int:instance_id>/role/<int:role_id>/scenario', methods=['GET'])
def get_scenario(instance_id, role_id):
    # Call the service function to get scenario details
    response, error = fetch_scenario_details(instance_id, role_id)
    
    if error:
        return jsonify(error), error['code']
    return jsonify(response), 200


# The polling api for frontend to update the data.
# Main logic in service level: /backend/service/instance_status.py
@player_bp.route('/instance/<int:instance_id>/check', methods=['GET'])
def check_status(instance_id):
    response, error = check_and_proceed_instance_status(instance_id)
    if error:
        return error
    return response
    

@player_bp.route('/instance/<int:instance_id>/decision', methods=['POST'])
def make_decision(instance_id):
    data = request.get_json()
    scenario_id = data.get('scenario_id')
    choice_id = data.get('choice_id')
    role_id = data.get('role_id')
    
    # Call the service function for the decision-making logic
    response, status_code = make_decision_service(instance_id, scenario_id, choice_id, role_id)
    
    return jsonify(response), status_code


@player_bp.route('/instance/<int:instance_id>/role/<int:role_id>/messages', methods=['GET'])
def get_messages(instance_id, role_id):
    # Call the service layer to fetch messages and files
    response, code = get_message_service(instance_id, role_id)
    
    return jsonify(response), code