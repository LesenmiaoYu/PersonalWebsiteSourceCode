from flask import Blueprint, jsonify

public_bp = Blueprint('public', __name__)

@public_bp.route('/hello', methods=['GET'])
def hello_world():
    return jsonify(message='Hello, World! This is a public API.')