import os
from cryptography.fernet import Fernet
import hashlib
import base64
from .models.manager import Manager
from .models.room import Room
from .models.location import Location

def insert_default_locations(db):
    try:
        if db.session.query(Location).count() == 0:
            default_locations = [
                Location(name='JFF'),
                Location(name='JKP'),
                Location(name='Zoom')
            ]
            db.session.add_all(default_locations)
            db.session.flush()
            # JFF
            default_rooms = [
                Room(name="A", location_id=default_locations[0].id),
                Room(name="B", location_id=default_locations[0].id),
                Room(name="C", location_id=default_locations[0].id),
                Room(name="D", location_id=default_locations[0].id),
                Room(name="E", location_id=default_locations[0].id),
                Room(name="F", location_id=default_locations[0].id),
                Room(name="G", location_id=default_locations[0].id),
                Room(name="J", location_id=default_locations[0].id),
                Room(name="K", location_id=default_locations[0].id),
                Room(name="L", location_id=default_locations[0].id),
                Room(name="M", location_id=default_locations[0].id),
                Room(name="N", location_id=default_locations[0].id),
            ]
            db.session.add_all(default_rooms)

            # JKP
            # 201A, 201C, 201D, 201E, 201F, 201G (201B is skipped)
            default_rooms = [
                Room(name="A", location_id=default_locations[1].id),
                Room(name="B", location_id=default_locations[1].id),
                Room(name="C", location_id=default_locations[1].id),
                Room(name="D", location_id=default_locations[1].id),
                Room(name="E", location_id=default_locations[1].id),
                Room(name="F", location_id=default_locations[1].id),
                Room(name="G", location_id=default_locations[1].id),
                Room(name="J", location_id=default_locations[1].id),
                Room(name="K", location_id=default_locations[1].id),
                Room(name="201A", location_id=default_locations[1].id),
                Room(name="201C", location_id=default_locations[1].id),
                Room(name="201D", location_id=default_locations[1].id),
                Room(name="201E", location_id=default_locations[1].id),
                Room(name="201F", location_id=default_locations[1].id),
                Room(name="201G", location_id=default_locations[1].id),
            ]
            db.session.add_all(default_rooms)

            # Zoom
            default_rooms = [
                Room(name="1", location_id=default_locations[2].id),
                Room(name="2", location_id=default_locations[2].id),
                Room(name="3", location_id=default_locations[2].id),
                Room(name="4", location_id=default_locations[2].id),
                Room(name="5", location_id=default_locations[2].id),
                Room(name="6", location_id=default_locations[2].id),
                Room(name="7", location_id=default_locations[2].id),
                Room(name="8", location_id=default_locations[2].id),
                Room(name="9", location_id=default_locations[2].id),
                Room(name="10", location_id=default_locations[2].id),
                Room(name="11", location_id=default_locations[2].id),
                Room(name="12", location_id=default_locations[2].id),
                Room(name="13", location_id=default_locations[2].id),
                Room(name="14", location_id=default_locations[2].id),
                Room(name="15", location_id=default_locations[2].id),
                Room(name="16", location_id=default_locations[2].id),
                Room(name="17", location_id=default_locations[2].id),
                Room(name="18", location_id=default_locations[2].id),
                Room(name="19", location_id=default_locations[2].id),
                Room(name="20", location_id=default_locations[2].id),
                Room(name="21", location_id=default_locations[2].id),
                Room(name="22", location_id=default_locations[2].id),
                Room(name="23", location_id=default_locations[2].id),
                Room(name="24", location_id=default_locations[2].id),
                Room(name="25", location_id=default_locations[2].id),
                Room(name="26", location_id=default_locations[2].id),
                Room(name="27", location_id=default_locations[2].id),
                Room(name="28", location_id=default_locations[2].id),
                Room(name="29", location_id=default_locations[2].id),
                Room(name="30", location_id=default_locations[2].id),
            ]
            db.session.add_all(default_rooms)
            db.session.commit()
    except Exception as e:
        db.session.rollback()


# Check if "trojan" manager exists; if not, create it
def insert_default_managers(db):
    if not Manager.query.filter_by(id='trojan').first():
        id = "trojan"
        pw = "fighton"
        key = os.getenv('ENCRYPTION_KEY')
        if not key:
            raise ValueError('ENCRYPTION_KEY environment variable not set')
        hash = hashlib.sha256(key.encode()).digest()
        fernet_key = base64.urlsafe_b64encode(hash)
        fernet = Fernet(fernet_key)
        encrypted_password = fernet.encrypt(pw.encode())
        admin_user = Manager(id=id, pw=encrypted_password)
        db.session.add(admin_user)
        db.session.commit()
