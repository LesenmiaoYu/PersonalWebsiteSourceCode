from ..extensions import db

class Message(db.Model):
    __tablename__ = 'message'
    id = db.Column(db.Integer, primary_key=True)
    game_instance_id = db.Column(db.Integer)
    content = db.Column(db.Text)
    role_id = db.Column(db.Integer)