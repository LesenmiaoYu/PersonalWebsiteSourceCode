from ..extensions import db

class ScenarioDecisionMapping(db.Model):
    __tablename__ = 'scenario_decision_mapping'
    id = db.Column(db.Integer, primary_key=True)
    from_scenario = db.Column(db.Integer)
    to_scenario = db.Column(db.Integer)
    choice_id = db.Column(db.Integer)

