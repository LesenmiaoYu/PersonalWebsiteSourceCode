from ..extensions import db
class Scenario(db.Model):
    __tablename__ = 'scenario'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String)
    game_id = db.Column(db.Integer)
    first_scenario = db.Column(db.Boolean)
    number = db.Column(db.Integer)
