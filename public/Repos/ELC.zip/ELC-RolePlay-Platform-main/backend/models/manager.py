from ..extensions import db

class Manager(db.Model):
    __tablename__ = 'manager'
    id = db.Column(db.String, primary_key=True)
    pw = db.Column(db.String)