from ..extensions import db

class ScenarioDecision(db.Model):
    __tablename__ = 'scenario_decision'
    id = db.Column(db.Integer, primary_key=True)
    instance_id = db.Column(db.Integer)
    scenario_id = db.Column(db.Integer)
    choice_id = db.Column(db.Integer)
