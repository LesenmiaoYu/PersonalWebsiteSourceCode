from ..extensions import db
from . import Message

class MessageFile(db.Model):
    __tablename__ = 'message_file'
    id = db.Column(db.Integer, primary_key=True)
    message_id = db.Column(db.Integer)
    url = db.Column(db.String)

