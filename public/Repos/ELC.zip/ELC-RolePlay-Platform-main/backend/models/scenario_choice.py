from ..extensions import db

class ScenarioChoice(db.Model):
    __tablename__ = 'scenario_choice'
    id = db.Column(db.Integer, primary_key=True)
    scenario_id = db.Column(db.Integer)
    content = db.Column(db.Text)
