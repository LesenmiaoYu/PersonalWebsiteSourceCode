from ..extensions import db

class ScenarioFile(db.Model):
    __tablename__ = 'scenario_file'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String)
    scenario_id = db.Column(db.Integer)
    url = db.Column(db.String)