from ..extensions import db

class InstanceStatus(db.Model):
    __tablename__ = 'instance_status'
    instance_id = db.Column(db.Integer, primary_key=True)
    current_scenario_id = db.Column(db.Integer)
    next_scenario_id = db.Column(db.Integer, nullable=True)  # Nullable
