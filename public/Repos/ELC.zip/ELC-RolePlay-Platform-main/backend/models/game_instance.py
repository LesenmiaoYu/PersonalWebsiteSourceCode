from ..extensions import db

class GameInstance(db.Model):
    __tablename__ = 'game_instance'
    id = db.Column(db.Integer, primary_key=True)
    game_id = db.Column(db.Integer)
    location_id = db.Column(db.Integer)
    room_id = db.Column(db.Integer)
    scenario_id = db.Column(db.Integer)
    state = db.Column(db.String)  # Note: 'created, ongoing, terminated'
    created_at = db.Column(db.DateTime)
    started_at = db.Column(db.DateTime)
    updated_at = db.Column(db.DateTime)
