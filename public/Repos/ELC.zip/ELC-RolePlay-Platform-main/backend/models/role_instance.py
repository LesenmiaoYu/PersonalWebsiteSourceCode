from ..extensions import db

class RoleInstance(db.Model):
    __tablename__ = 'role_instance'
    instance_id = db.Column(db.Integer, primary_key=True)
    role_id = db.Column(db.Integer, primary_key=True)
