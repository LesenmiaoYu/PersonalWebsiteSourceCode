# Project Name: ELC Role-play Platform

## Introduction
The Experiential Learning Center (ELC) at the Marshall School of Business facilitates interactive exercises, such as role-plays, simulations, and games, across undergraduate, graduate, and executive education courses at USC. Instead of attending traditional lectures, students periodically visit the ELC to participate in dynamic, hands-on learning activities.

This platform enables the ELC to create and manage a wide range of role-play exercises. It supports multiple breakout rooms, each running either a shared scenario or its own unique scenario. Participants join these rooms and log in based on assigned roles. The system delivers role-specific information directly to participants' devices. As the scenario progresses, new information can be issued to specific roles, questionnaires can be sent, and the storyline can adapt based on participant choices. Once an exercise concludes, the platform aggregates results from all rooms for review and analysis.

A key objective is that non-technical administrators can easily create, customize, and run these exercises. This includes defining scenarios, assigning roles, introducing disruptions, administering questionnaires, and providing conditional instructions. The platform's intuitive interface and flexible configuration options allow the ELC to implement a wide variety of simulations without requiring programming expertise.

Ultimately, this platform empowers the ELC to efficiently generate, deploy, and reuse custom role-play exercises, enhancing the learning experience and driving deeper engagement with course concepts.

## Key Features
- Supports multiple breakout rooms running concurrent scenarios.
- Ability to run a single scenario across all rooms or assign unique scenarios to each room.
- Straightforward interfaces enabling non-technical administrators to configure and launch role-play exercises.
- Real-time delivery of role-specific information and scenario updates.
- Integration of questionnaires and scenario branching based on participant responses.
- Aggregated results and reports for post-exercise review and discussion.

## Technical Overview
The platform is containerized using Docker, with a Flask-based backend, a React-based frontend, and a MySQL database. Deployment is managed through Digital Ocean. This architecture ensures a portable, scalable, and maintainable environment that can be easily updated and managed by the ELC's dedicated technical staff.

## Getting Started

### System Requirements
- A modern web browser (Chrome, Firefox, Safari, or Edge).
- Stable internet connection.

### Running the Application

The application is hosted on the Digital Ocean deployment URL running by USC ELC. To access the application webpage, simply access the website and follow the instruction on each page to perform related operations.

## Features

### Admin Side

**Logging in (admin):** Administrators authenticate using a predefined token or credential. Once logged in, they gain access to administrative tools.
Username: trojan
Password: fighton
![Log in](./managerLogin.png)

**Creating & Deleting Game Templates:** Administrators define templates that set parameters such as scenarios, roles, decision mapping, and uploaded files. Templates can be saved and removed.
![Create Game](./adminSetUp.png)

**File Uploads:** Administrators can upload files (PDFs, images, text) that participants view during scenarios.

**Creating Game Instances:** Administrators spawn new game instances using selected templates. Each instance runs independently.
![Run Instances](./runInstances.png)

**Monitoring Game Instances:** A dashboard enables real-time oversight of ongoing sessions, including participant progress and scenario events.
![Manage Instances](./manageInstances.png)

**Sending Messages to Instances:** Administrators can send announcements or instructions (in PDF or text) to rooms, roles, or individual participants.
![Send Messages](./sendMessages.png)

**Proceeding Games:** Administrators can advance the scenario to subsequent phases, revealing new information and triggering decision-questionnaire.

**Gathering Insights on Past Instances Ran:** After sessions conclude, reports summarize participant actions and outcomes (visualized via a tree graph).
![Result Visualization](./resultVisualization.png)

### Player Side

**Selecting Room to Join:** Participants log in to the assigned room as directed by the ELC staff.
![View Instances](./viewAvailInstances.png)

**Selecting Role to Fill:** Participants select or are assigned a role, gaining access to role-specific information.

**Reading PDFs:** Participants can view provided PDF documents relevant to their roles or the scenario.

**Checking New Messages:** Participants receive and read notifications, instructions, or additional materials.
![Check Messages](./checkingMessages.png)

**Making Choices (Optional):** Certain scenarios prompt the decision-making participants to make decisions that influence subsequent events or storylines.

## Gameplay Walkthrough
![Walk Through](./walkThroughGraph.jpg)

## Deployment
The ELC's dedicated programmer is responsible for deploying and maintaining the platform on Digital Ocean. Once deployed, the platform can be accessed at:

[https://roleplay.elcexercises.org/](https://roleplay.elcexercises.org/)

If updates are made to the codebase, please coordinate with the ELC programmer to redeploy the latest version.

## For Future Developers
The source code will be stored in a private github repo which will be under ELC's github account. In addition to this documentation, there'll be a README file for running the application on any devices and an API documentation for development references.

## Staging vs Production
A staging environment can be used to test new features or scenarios without affecting ongoing sessions. The ELC programmer can maintain both staging and production environments, ensuring that updates are thoroughly validated before going live.

## Security Considerations
The platform does not store sensitive personal information. Its primary purpose is to deliver scenario content and record participant responses. While the security risk is low, the platform maintains basic measures to prevent unauthorized access or disruption.

## Common Threats and Mitigation

**Hardcoded Admin Token:** The administrator's login token is currently embedded in the code. While this is sufficient for our use case, future improvements could include more robust authentication methods.

**Database Growth Over Time:** All instances and uploaded files are stored indefinitely, potentially leading to large database sizes over many years. Periodic cleanup of older sessions is recommended.

**Third-Party Library Dependencies:** The platform relies on `react-force-graph` for visualization. While it is a popular and actively maintained library, the reliance on third-party code carries a minor risk if the library becomes unsupported in the far future.

## Troubleshooting and FAQs
If issues arise:
- Verify the environment (staging vs production).
- Check Flask/React environment file.
- Check server logs and Docker container status.
- Use Postman or a similar tool to confirm API endpoint functionality.
- If further investigation is needed, clone the repository and run the application locally.

Additional resources:
- GitHub Repository: you will have access to the repo as we will be changing the ownership
- API Documentation: [notion](notion.so/API-Docs-11c75797b6578058b4a3cdac982171ba)

## Support and Contact
For assistance or inquiries related to future enhancements, please reach out:

**Front-End Team**  
Tommy Schindler: tsschind@usc.edu  
Sabrina Yang: yangsabr@usc.edu  
David Yu: dyu18149@usc.edu

**Back-End Team**  
Sang Kim: kim305@usc.edu  
Quanyong Bi: quanyong@usc.edu  
Yaxi Zeng: yaxizeng@usc.edu

We appreciate the opportunity to support the Marshall School of Business in creating innovative learning experiences. Thank you for your collaboration, and Fight On!
