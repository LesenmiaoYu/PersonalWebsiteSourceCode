import React, { useState, useEffect } from 'react';
import Dropdown from '../components/Dropdown';
import '.././Design.css';
import './AdminSetupPage.css';
import MultiSelect from "../components/MultiSelect";

function AdminSetupPage() {
    const [games, setGames] = useState([]);


    useEffect(() => {
        fetchGames();
    }, []);

    const fetchGames = async () => {
        try {
            const response = await fetch('/api/admin/games', {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('authToken')}`
                }
            });
            if (!response.ok) {
                throw new Error('Failed to fetch games');
            }
            const data = await response.json();
            console.log(data.games);
            setGames(data.games);
        } catch (error) {
            console.error('Error fetching games:', error);
        }
    };

    const [searchText, setSearchText] = useState('');
    const [showNewModal, setShowNewModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [showRunModal, setShowRunModal] = useState(false);
    const [MultiSelectOpen, setMultiSelectOpen] = useState(false);
    const [multiSelectOptions, setMultiSelectOptions] = useState(null);
    const [currentGame, setCurrentGame] = useState(null);
    const [modalPage, setModalPage] = useState(1);
    const [selectedRooms, setSelectedRooms] = useState([]);
    const roomMappings = [['A', 'B', 'C', 'D', 'E', 'F', 'G', 'J', 'K', 'L', 'M', 'N'], ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'J', 'K', '201A', '201C', '201D', '201E', '201F', '201G'], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]];

    const [selectedScenario, setSelectedScenario] = useState(null);
    const [file, setFile] = useState(null);


    // useEffect(() => {
    //     // Check if decision rounds need updating only if there are choices
    //     const scenariosNeedUpdate = currentGame?.scenarios.some(scenario => scenario.choices.length > 0 && !scenario.isDecisionRound);

    //     if (scenariosNeedUpdate) {
    //         const updatedScenarios = currentGame.scenarios.map(scenario => {
    //             if (scenario.choices.length > 0 && !scenario.isDecisionRound) {
    //                 return { ...scenario, isDecisionRound: true };
    //             }
    //             return scenario;
    //         });

    //         setCurrentGame(currentGame => ({
    //             ...currentGame,
    //             scenarios: updatedScenarios
    //         }));
    //     }
    // }, [currentGame]);

    const openNewModal = () => {
        setShowNewModal(true);
        setModalPage(1);
        setCurrentGame({
            name: { game_name: "" },
            roles: [],
            scenarios: [],
            scenario_decision_mappings: [],
            room_number: ""
        });
    };

    const closeNewModal = () => {
        setShowNewModal(false);
    };

    const openEditModal = (game) => {
        setShowEditModal(true);
        setCurrentGame({
            ...game, roles: game.roles.map(role => ({
                ...role,
                deciding: role.principal
            })), scenarios: game.scenarios.map((scenario) => ({
                ...scenario, choices: scenario.choices.map((choice, cInd) => ({
                    ...choice,
                    choice_number: choice.id
                })),
            })), id: game.id, scenario_decision_mappings: adjustMapping(game) || []
        });
        setModalPage(1);
    };

    const adjustMapping = (game) => {
        let newMapping = [];
        for (let i = 0; i < game.scenario_decision_mappings.length; i++) {
            let curr = game.scenario_decision_mappings[i];
            if (curr.choice_id !== null) {
                curr = { ...curr, choice_number: curr.choice_id }
            }
            for (let j = 0; j < game.scenarios.length; j++) {
                if (game.scenarios[j].id === game.scenario_decision_mappings[i].from_scenario) {
                    curr.from_scenario = game.scenarios[j].number;
                }
                if (game.scenarios[j].id === game.scenario_decision_mappings[i].to_scenario) {
                    curr.to_scenario = game.scenarios[j].number;
                }
            }
            newMapping.push(curr);
        }
        return newMapping;
    };


    const closeEditModal = () => {
        setShowEditModal(false);
    };

    const openRunModal = (game) => {
        setShowRunModal(true);
        setCurrentGame({ ...game });
    };

    const closeRunModal = (game) => {
        setShowRunModal(false);
        setMultiSelectOpen(false);
    };

    const handleSearchChange = (event) => {
        setSearchText(event.target.value);
    };

    const handleNextPage = () => {
        setModalPage(2);
    };

    const handlePreviousPage = () => {
        setModalPage(1);
    };

    const handleAddRole = () => {
        const newRole = { name: "", mandatory: false, deciding: false };
        setCurrentGame({ ...currentGame, roles: [...currentGame.roles, newRole] });
    };

    const handleRemoveRole = (index) => {
        const updatedRoles = currentGame.roles.filter((_, i) => i !== index);
        setCurrentGame({ ...currentGame, roles: updatedRoles });
    };

    const handleAddScenario = () => {
        const newScenario = {
            name: "",
            number: currentGame.scenarios.length + 1,
            first_scenario: currentGame.scenarios.length === 0,
            isDecisionRound: false,
            choices: [],
            files: []
        };
        setCurrentGame({
            ...currentGame,
            scenarios: [...currentGame.scenarios, newScenario]
        });
    };

    const handleRemoveScenario = (index) => {
        const updatedScenarios = currentGame.scenarios.filter((_, i) => i !== index);
        setCurrentGame({ ...currentGame, scenarios: updatedScenarios });
    };

    const handleSubmit = () => {
        console.log('Current game:', currentGame);

        if (currentGame.name.game_name === "") {
            alert("Game name is required");
            return;
        }
        const hasDecidingRole = currentGame.roles.some(role => role.deciding);
        if (!hasDecidingRole) {
            alert("Exactly one role must be marked as Deciding.");
            return;
        }

        /*for(let i = 0; i < currentGame.scenarios.length - 1; i++){
            if(!currentGame.scenarios[i].isDecisionRound){
                currentGame.scenario_decision_mappings.push({"from_scenario": currentGame.scenarios[i].scenario_number, "to_scenario": currentGame.scenarios[i].scenario_number + 1})
            }
        }*/

        for (let i = 0; i < currentGame.scenario_decision_mappings.length; i++) {
            let cn = currentGame.scenario_decision_mappings[i].choice_number;
            if (!cn) {
                continue;
            }
            let fs = currentGame.scenario_decision_mappings[i].from_scenario;
            let scenarioIndex = -1;
            for (let j = 0; j < currentGame.scenarios.length; j++) {
                if (currentGame.scenarios[j].number === fs) {
                    scenarioIndex = j;
                }
            }
            if (scenarioIndex === -1) {
                console.log('deleted mapping for scen' + fs);
                currentGame.scenario_decision_mappings.splice(i, 1);
                i -= 1;
                continue
            }

            let found = false;
            for (let j = 0; j < currentGame.scenarios[scenarioIndex].choices.length; j++) {
                if (currentGame.scenarios[scenarioIndex].choices[j].choice_number === cn) {
                    found = true;
                }
            }
            if (!found) {
                console.log('deleted mapping for choice ' + cn);
                currentGame.scenario_decision_mappings.splice(i, 1);
                i -= 1;
            }
        }

        const gameData = {
            "name": currentGame.name,
            "roles": currentGame.roles.map(role => ({
                "name": role.name,
                "mandatory": role.mandatory,
                "principal": role.deciding // 'deciding' in frontend is 'principal' in backend
            })),
            "scenarios": currentGame.scenarios.map((scenario, index) => ({
                "name": scenario.name,
                "scenario_number": scenario.number,
                "first_scenario": index === 0,
                "choices": scenario.choices.map((choice, choiceIndex) => ({
                    "content": choice.content,
                    "choice_number": choice.choice_number // Modified
                })),
                "scenario_files": scenario.files // You'll need to implement file upload functionality
            })),
            "scenario_decision_mappings": currentGame.scenario_decision_mappings.map(mapping => ({
                "from_scenario": mapping.from_scenario,
                "to_scenario": mapping.to_scenario,
                "choice_number": mapping.choice_number
            }))
        };

        if (currentGame.id) {
            // Delete existing game before creating the updated one

            fetch('/api/admin/games', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('authToken')}`
                },
                body: JSON.stringify({ game_id: currentGame.id })
            })
                .then((response) => {
                    if (!response.ok) {
                        throw new Error('Error deleting game');
                    }
                    console.log('Game deleted successfully.');

                    // Proceed to create the new game after deletion
                    createGame(gameData);
                })
                .catch((error) => {
                    console.error('Error during game deletion:', error);
                    alert('Failed to delete the existing game. Please try again.');
                });
        } else {
            // Create a new game if no existing ID
            createGame(gameData);
        }
    };

    const createGame = (gameData) => {
        console.log(JSON.stringify({ game: gameData }));
        fetch('/api/admin/games', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${localStorage.getItem('authToken')}`
            },
            body: JSON.stringify({ game: gameData })
        })
            .then((response) => {
                if (!response.ok) {
                    //console.log(response.json())
                    throw new Error('Error creating game');
                }
                return response.json();
            })
            .then((data) => {
                console.log('Success:', data);
                const gameId = data.game_id;
                localStorage.setItem('lastCreatedGameId', gameId);
                alert(`Game ${currentGame.id ? 'updated' : 'created'} successfully!`);

                setShowNewModal(false);
                setShowEditModal(false);

                fetchGames();
            })
            .catch((error) => {
                console.error('Error during game creation:', error);
                alert('Failed to create game. Please try again.');
            });
    };


    const handleDelete = () => {
        if (!currentGame || !currentGame.id) {
            alert("No game selected for deletion.");
            return;
        }

        if (window.confirm("Are you sure you want to delete this game?")) {
            const deleteData = {
                "game_id": currentGame.id
            };

            fetch('/api/admin/games', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('authToken')}`
                },
                body: JSON.stringify(deleteData)
            })
                .then((response) => {
                    if (!response.ok) {
                        throw new Error('Error deleting game');
                    }
                    return response.json();
                })
                .then((data) => {
                    console.log('Success:', data);
                    alert(`Game deleted successfully!`);

                    setShowEditModal(false);
                    setCurrentGame(null);

                    fetchGames();
                })
                .catch((error) => {
                    console.error('Error during game deletion:', error);
                    alert('Failed to delete game. Please try again.');
                });
        }
    };



    const handleRun = () => {
        const createInstancePromises = selectedRooms.map(roomId => {
            const gameInstanceData = {
                "game_id": currentGame.id,
                "location_id": currentGame.location,
                "room_id": roomId,
            };

            return fetch('/api/admin/game-instances', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('authToken')}`
                },
                body: JSON.stringify(gameInstanceData)
            })
                .then(response => {
                    if (!response.ok) {
                        if (response.status === 400) {
                            return response.json().then(data => {
                                throw new Error(data.message || 'Invalid game data');
                            });
                        } else {
                            throw new Error('Error creating game instance');
                        }
                    }
                    return response.json();
                });
        });

        Promise.all(createInstancePromises)
            .then(results => {
                console.log('Success:', results);
                const instanceIds = results.map(data => data.game_instance.instance_id);
                localStorage.setItem('lastCreatedInstanceIds', JSON.stringify(instanceIds));
                alert(`Game Instances created successfully! Game Instance IDs: ${instanceIds.join(', ')} for Game ID: ${currentGame.id}`);
            })
            .catch((error) => {
                console.error('Error during game instance creation:', error);
                alert(error.message || 'Failed to create game instances. Please try again.');
            });
    };

    const handleRoleDecidingChange = (index, isChecked) => {
        const updatedRoles = currentGame.roles.map((role, i) => (
            i === index ? { ...role, deciding: isChecked } : { ...role, deciding: false }
        ));
        setCurrentGame({ ...currentGame, roles: updatedRoles });
    };

    const handleAddChoice = (scenarioIndex) => {
        const newChoice = { content: '', choice_number: currentGame.scenarios[scenarioIndex].choices[currentGame.scenarios[scenarioIndex].choices.length - 1].choice_number + 1, goTo: null };
        const updatedScenarios = currentGame.scenarios.map((s, i) => (
            i === scenarioIndex ? { ...s, choices: [...s.choices, newChoice] } : s
        ));
        setCurrentGame({ ...currentGame, scenarios: updatedScenarios });
    };

    const handleRemoveChoice = (scenarioIndex, choiceIndex) => {
        const updatedChoices = currentGame.scenarios[scenarioIndex].choices.filter((_, i) => i !== choiceIndex);
        const updatedScenarios = currentGame.scenarios.map((s, i) => (
            i === scenarioIndex ? { ...s, choices: updatedChoices } : s
        ));
        setCurrentGame({ ...currentGame, scenarios: updatedScenarios });
    };

    const filteredGames = games.filter(game =>
        game.name.toLowerCase().includes(searchText.toLowerCase())
    );

    const showMultiSelect = (loc) => {
        let options = [];
        for (let i = 0; i < roomMappings[loc - 1].length; i++) {
            options.push({ value: `${i + 1}`, label: `Room ${roomMappings[loc - 1][i]}` });
        }

        setMultiSelectOptions(options);
        setMultiSelectOpen(true);
    }

    const getDefaultMapping = (scenarioNumber, choiceNumber) => {
        console.log(currentGame.scenario_decision_mappings);
        console.log('SN: ' + scenarioNumber + ', CN: ' + choiceNumber);
        let res = null;
        if (choiceNumber === null) {
            for (let i = 0; i < currentGame.scenario_decision_mappings.length; i++) {
                if (currentGame.scenario_decision_mappings[i].from_scenario === scenarioNumber) {
                    let dest = currentGame.scenario_decision_mappings[i].to_scenario;
                    let destName = null;
                    for (let j = 0; j < currentGame.scenarios.length; j++) {
                        if (currentGame.scenarios[j].number === dest) {
                            destName = currentGame.scenarios[j].name;
                        }
                    }
                    res = { value: dest, label: `Scenario ${dest}: ${destName}` };
                }
            }
        } else {
            for (let i = 0; i < currentGame.scenario_decision_mappings.length; i++) {
                if (currentGame.scenario_decision_mappings[i].from_scenario === scenarioNumber && currentGame.scenario_decision_mappings[i].choice_number === choiceNumber) {
                    let dest = currentGame.scenario_decision_mappings[i].to_scenario;
                    let destName = null;
                    for (let j = 0; j < currentGame.scenarios.length; j++) {
                        if (currentGame.scenarios[j].number === dest) {
                            destName = currentGame.scenarios[j].name;
                        }
                    }
                    res = { value: dest, label: `Scenario ${dest}: ${destName}` };
                }
            }
        }
        return res;
    };


    const handleUpload = () => {
        if (!selectedScenario || !file) {
            alert('Please select a scenario and a file.');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);

        fetch(`/api/upload_file`, {
            method: 'POST',
            body: formData,
        })
            .then(response => response.ok ? response.json() : Promise.reject('Failed to upload'))
            .then(data => {
                console.log(`File uploaded for scenario ${currentGame.scenarios[selectedScenario].name}: URL - ${data.url}`);
                console.log(currentGame.scenarios[selectedScenario].files);
                currentGame.scenarios[selectedScenario].files.push({ "name": currentGame.scenarios[selectedScenario].name, "url": data.url });
                setSelectedScenario(''); // Clear the selected scenario
                setFile(null); // Clear the file input
            })
            .catch(error => {
                console.error(`Error during file upload for scenario ${selectedScenario}:`, error);
            });
    };


    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%', maxWidth: '800px' }}>
                <br /><br /><br />
                <button className="edit-button" style={{ alignSelf: 'flex-start' }} onClick={openNewModal}>Create New Game</button>

                <div className="game-container">
                    <p style={{ fontSize: '1em', color: '#666', margin: '0' }}>
                        You can delete a game after clicking the Edit button.
                    </p>
                    {games.length > 0 ? (
                        games.map(game => (
                            <div key={game.id} id={`game-${game.id}`} className="game-block">
                                <div className="game-details">
                                    <h3>{game.name}</h3>
                                    <p className="game-info">
                                        Roles: {game.roles.length} | Scenarios: {game.scenarios.length}
                                    </p>
                                </div>
                                <button className="edit-button" onClick={() => openEditModal(game)}>Edit</button>
                                <button className="edit-button" onClick={() => openRunModal(game)}>Run</button>

                            </div>
                        ))
                    ) : (
                        <div className="game-block">
                            <h3>No games found.</h3>
                        </div>
                    )}
                </div>



                {(showRunModal) && currentGame && (
                    <div className="modal">
                        <div className="modal-content">
                            <span className="close" onClick={closeRunModal}>&times;</span>

                            <div>
                                <div style={{ display: 'flex', flexDirection: 'row', gap: '10px' }}>
                                    <p className="modal-title">Currently editing: {currentGame.name}</p>
                                </div>
                                <div >
                                    <p className="section-title">Select location and rooms to run:</p>
                                    <Dropdown
                                        options={[
                                            { value: 'jff', label: 'Fertitta Hall Basement', id: 1 },
                                            { value: 'pop', label: 'Popovich Third Floor', id: 2 },
                                            { value: 'zoom', label: 'Online Zoom Room', id: 3 },
                                        ]}
                                        placeholder="Select Location"
                                        onSelect={(option) => { setCurrentGame({ ...currentGame, location: option.id }); showMultiSelect(option.id); }}
                                    />
                                    <br />
                                    {MultiSelectOpen ? (
                                        <MultiSelect
                                            options={multiSelectOptions}
                                            selectedValues={selectedRooms}
                                            onSelectionChange={setSelectedRooms}
                                        />
                                    ) : (
                                        <p>Select a location to view rooms</p>
                                    )}
                                </div>
                                <br /><br /><br />
                                <button onClick={() => { handleRun(); closeRunModal(); }} className="save-button">Run</button>

                            </div>
                        </div>
                    </div>
                )
                }


                {(showNewModal || showEditModal) && currentGame && (
                    <div className="modal">
                        <div className="modal-content">
                            <span className="close" onClick={showNewModal ? closeNewModal : closeEditModal}>&times;</span>
                            {modalPage === 1 ? (
                                <div>
                                    <div style={{ display: 'flex', flexDirection: 'row', gap: '10px' }}>
                                        <p className="modal-title">Currently editing:</p>
                                        <input
                                            type="text"
                                            value={typeof currentGame?.name === 'string' ? currentGame.name : ''}
                                            style={{
                                                height: '30px',
                                                border: '1px solid #ccc',
                                                fontSize: '17px',
                                                marginTop: '6px'
                                            }}
                                            placeholder="Game Name"
                                            className="name-input-field"
                                            onChange={(e) => setCurrentGame({
                                                ...currentGame,
                                                name: e.target.value
                                            })}
                                        />
                                    </div>

                                    <p className="section-title">Roles:</p>
                                    <p style={{ fontSize: '0.8em', color: '#666', margin: '0' }}>
                                        (Please mark exactly one role as Deciding)
                                    </p>
                                    {currentGame.roles.map((role, index) => (
                                        <div key={index} className="role-input-group">
                                            <input type="text" value={role.name} className="input-field" onChange={(e) => {
                                                const updatedRoles = currentGame.roles.map((r, i) => (
                                                    i === index ? { ...r, name: e.target.value } : r
                                                ));
                                                setCurrentGame({ ...currentGame, roles: updatedRoles });
                                            }} />
                                            <label className="checkbox-label">
                                                <input
                                                    type="checkbox"
                                                    checked={role.mandatory}
                                                    onChange={(e) => {
                                                        const updatedRoles = currentGame.roles.map((r, i) => (
                                                            i === index ? { ...r, mandatory: e.target.checked } : r
                                                        ));
                                                        setCurrentGame({ ...currentGame, roles: updatedRoles });
                                                    }}
                                                />
                                                Mandatory
                                            </label>
                                            <label className="checkbox-label">
                                                <input
                                                    type="checkbox"
                                                    checked={role.deciding}
                                                    onChange={(e) => handleRoleDecidingChange(index, e.target.checked)}
                                                />
                                                Deciding
                                            </label>
                                            <span className="remove-role" onClick={() => handleRemoveRole(index)}
                                                style={{ cursor: 'pointer', color: 'red', fontWeight: 'bold', marginLeft: '10px' }}
                                                onMouseOver={(e) => e.target.style.color = 'darkred'}
                                                onMouseOut={(e) => e.target.style.color = 'red'}>x</span>
                                        </div>
                                    ))}
                                    <button onClick={handleAddRole} className="add-role-button">Add New Role</button>
                                    <p className="section-title">Scenarios:</p>
                                    <p style={{ fontSize: '0.8em', color: '#666', margin: '0' }}>
                                        (The first scenario will be the starting point of the game)
                                    </p>
                                    {currentGame.scenarios.map((scenario, index) => (
                                        <div key={index} className="scenario-input-group">
                                            <input
                                                type="text"
                                                value={scenario.name}
                                                placeholder={index === 0 ? "The First Scenario Name" : "Scenario Name"}
                                                className="input-field"
                                                onChange={(e) => {
                                                    const updatedScenarios = currentGame.scenarios.map((s, i) => {
                                                        if (i === index) {
                                                            return {
                                                                ...s,
                                                                name: e.target.value,
                                                                first_scenario: i === 0 // Always set first scenario for index 0
                                                            };
                                                        }
                                                        return s;
                                                    });



                                                    setCurrentGame({ ...currentGame, scenarios: updatedScenarios });
                                                }}
                                            />

                                            <label className="checkbox-label">
                                                <input
                                                    type="checkbox"
                                                    checked={scenario.isDecisionRound || scenario.choices.length !== 0 || false}
                                                    onChange={(e) => {
                                                        const updatedScenarios = currentGame.scenarios.map((s, i) => (
                                                            i === index ? { ...s, isDecisionRound: e.target.checked, choices: e.target.checked ? (s.choices.length > 0 ? s.choices : [{ content: "", choice_number: 1, goTo: null }]) : [] } : s
                                                        ));
                                                        setCurrentGame({ ...currentGame, scenarios: updatedScenarios });
                                                    }}
                                                />
                                                Choice-making round
                                            </label>
                                            <span className="remove-scenario" onClick={() => handleRemoveScenario(index)}
                                                style={{ cursor: 'pointer', color: 'red', fontWeight: 'bold', marginLeft: '10px' }}
                                                onMouseOver={(e) => e.target.style.color = 'darkred'}
                                                onMouseOut={(e) => e.target.style.color = 'red'}>x</span>
                                        </div>
                                    ))}


                                    <button onClick={handleAddScenario} className="add-scenario-button">Add New Scenario</button>
                                    <div className="button-group">
                                        <button onClick={handleNextPage} className="next-button">Next</button>
                                        <button onClick={handleSubmit} className="save-button">Save</button>
                                        <button onClick={handleDelete} className="delete-button">Delete</button>
                                        {/* <button className="edit-button" onClick={handleDelete}>Delete</button> */}

                                    </div>
                                </div>
                            ) : (
                                // Page 2
                                <>
                                    <p className="section-title">Specify Game Flow:</p>
                                    {currentGame.scenarios.map((scenario, index) => (
                                        <div key={index} className="scenario-choice-group">
                                            <h2>Scenario {scenario.number}:</h2>
                                            <div className="scenario-row">
                                                <input
                                                    type="text"
                                                    value={scenario.name}
                                                    className="input-field scenario-name"
                                                    placeholder="Scenario Name"
                                                    onChange={(e) => {
                                                        const updatedScenarios = currentGame.scenarios.map((s, i) => (
                                                            i === index ? { ...s, name: e.target.value } : s
                                                        ));
                                                        setCurrentGame({ ...currentGame, scenarios: updatedScenarios });
                                                    }}
                                                />
                                            </div>
                                            {scenario.choices.length > 0 ? (
                                                <div>
                                                    <p>Choices:</p>
                                                    {scenario.choices.map((choice, choiceIndex) => (
                                                        <div key={choiceIndex} className="choice-input-group scenario-row">
                                                            <input
                                                                type="text"
                                                                value={choice.content}
                                                                className="input-field choice-text"
                                                                placeholder={`Choice Text (e.g., A, B, C...)`}
                                                                onChange={(e) => {
                                                                    const updatedChoices = scenario.choices.map((c, ci) => (
                                                                        ci === choiceIndex ? { ...c, content: e.target.value } : c
                                                                    ));
                                                                    const updatedScenarios = currentGame.scenarios.map((s, i) => (
                                                                        i === index ? { ...s, choices: updatedChoices } : s
                                                                    ));
                                                                    setCurrentGame({
                                                                        ...currentGame,
                                                                        scenarios: updatedScenarios
                                                                    });
                                                                }}
                                                            />
                                                            <label className="go-to-label">GO TO:</label>
                                                            <Dropdown
                                                                options={currentGame.scenarios.map((s) => ({
                                                                    value: s.number,
                                                                    label: `Scenario ${s.number}: ${s.name}`
                                                                }))}
                                                                def={getDefaultMapping(scenario.number, choice.choice_number)}
                                                                value={currentGame.scenario_decision_mappings.find(m => m.from_scenario === scenario.number && m.choice_number === choice.choice_number)?.to_scenario}
                                                                placeholder="Select Scenario"
                                                                className="go-to-dropdown"
                                                                onSelect={(option) => {
                                                                    const existingMappingIndex = currentGame.scenario_decision_mappings.findIndex(m => m.from_scenario === scenario.number && m.choice_number === choice.choice_number);
                                                                    let newMappings = [...currentGame.scenario_decision_mappings];
                                                                    if (existingMappingIndex > -1) {
                                                                        console.log('CNInd:' + choiceIndex);
                                                                        console.log('CN: ' + choice.choice_number);
                                                                        newMappings[existingMappingIndex] = {
                                                                            ...newMappings[existingMappingIndex],
                                                                            to_scenario: option.value
                                                                        };
                                                                    } else {
                                                                        console.log('CN:' + choice.choice_number);
                                                                        newMappings.push({
                                                                            from_scenario: scenario.number,
                                                                            to_scenario: option.value,
                                                                            choice_number: choice.choice_number
                                                                        });
                                                                    }
                                                                    setCurrentGame({
                                                                        ...currentGame,
                                                                        scenario_decision_mappings: newMappings
                                                                        //scenarios[]
                                                                    });
                                                                }}
                                                            />
                                                            <span className="remove-choice"
                                                                onClick={() => handleRemoveChoice(index, choiceIndex)}>x</span>
                                                        </div>
                                                    ))}
                                                    <button onClick={() => handleAddChoice(index)}
                                                        className="add-choice-button">Add New Choice
                                                    </button>
                                                </div>
                                            ) : (
                                                <div>
                                                    <label className="go-to-label">GO TO:</label>
                                                    <Dropdown
                                                        options={currentGame.scenarios.map((s) => ({
                                                            value: s.number,
                                                            label: `Scenario ${s.number}: ${s.name}`
                                                        }))}
                                                        def={getDefaultMapping(scenario.number, null)}
                                                        value={currentGame.scenario_decision_mappings.find(m => m.from_scenario === scenario.number)?.to_scenario}
                                                        placeholder="Select Scenario"
                                                        className="go-to-dropdown"
                                                        onSelect={(option) => {
                                                            const existingMappingIndex = currentGame.scenario_decision_mappings.findIndex(m => m.from_scenario === scenario.number);
                                                            let newMappings = [...currentGame.scenario_decision_mappings];
                                                            if (existingMappingIndex > -1) {
                                                                newMappings[existingMappingIndex] = {
                                                                    ...newMappings[existingMappingIndex],
                                                                    to_scenario: option.value
                                                                };
                                                            } else {
                                                                newMappings.push({
                                                                    from_scenario: scenario.number,
                                                                    to_scenario: option.value
                                                                });
                                                            }
                                                            setCurrentGame({
                                                                ...currentGame,
                                                                scenario_decision_mappings: newMappings
                                                                //scenarios[]
                                                            });
                                                        }}
                                                    />
                                                </div>
                                            )}
                                        </div>
                                    ))}

                                    <div>
                                        <p className="section-title">File Upload</p>
                                        <select value={selectedScenario}
                                            onChange={(e) => setSelectedScenario(e.target.value)}>
                                            <option value="">Select a Scenario</option>
                                            {currentGame.scenarios.map((scenario, index) => (
                                                <option key={index} value={index}>
                                                    {scenario.name}
                                                </option>
                                            ))}
                                        </select>
                                        <input type="file" onChange={(e) => setFile(e.target.files[0])} />
                                        <button onClick={handleUpload}>Upload File</button>
                                    </div>

                                    <div className="button-group">
                                        <button onClick={handlePreviousPage} className="previous-button">Previous</button>
                                        <button onClick={handleSubmit} className="save-button">Save</button>
                                    </div>
                                </>


                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

export default AdminSetupPage;
