import React, { useState } from 'react';
import {useNavigate} from 'react-router-dom';
import '.././Design.css';

function ManagerLogin() {
  const [id, setId] = useState('');
  const [pw, setPw] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const authenticateManager = () => {
    fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, pw }),
    })
      .then((response) => {
        if(!response.ok){
          if (response.status===400){
            alert('Missing Login Field');
          }else{
            alert('Invalid Login Credentials');
          }
          throw new Error('Invalid Login');
        }
        return response.json();
      })
      .then((data) => {
        localStorage.setItem('authToken', data.access_token);
        navigate('/setup'/*, {state: {token: data.access_token}}*/);
      })
      .catch((error) => {
        console.error('Error during authentication:', error)
      });
  };

  return (
    <div>

      <br />
      <br />

      <div className='Login'>
        <br />
        <h1>Manager Login</h1>
        <input
        type="text"
        placeholder="ID"
        value={id}
        onChange={(e) => setId(e.target.value)}
        />
        <br />
        <br />
        <input
          type="password"
          placeholder="Password"
          value={pw}
          onChange={(e) => setPw(e.target.value)}
        />

        <br />
        <br />

        <button onClick={authenticateManager}>Login</button>
        {message && <p>{message}</p>}
      </div>
    </div>
  );
}

export default ManagerLogin;
