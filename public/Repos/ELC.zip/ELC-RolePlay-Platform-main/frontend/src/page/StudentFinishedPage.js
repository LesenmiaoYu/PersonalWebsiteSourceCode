import React, { useState } from 'react';
import '.././Design.css';

function StudentFinishedPage() {

    return(
        <div style={{textAlign: 'center'}}>
            <h1>Game Complete</h1> 
            <h1>Thank you for participating!</h1> 
        </div>
    );
}

export default StudentFinishedPage;