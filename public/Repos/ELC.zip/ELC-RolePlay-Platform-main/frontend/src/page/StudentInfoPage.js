import React, { useEffect, useState } from 'react';
import {useNavigate, useLocation} from 'react-router-dom';
import '.././Design.css';
import '../components/Messages.css';
import Modal from '../components/Modal';
import Dropdown from '../components/Dropdown';

const POLLING_INTERVAL = 5000;

function StudentInfoPage() {

    const [options, setOptions] = useState([ //Dummy Values for the time being
        { label: 'Choice #1', value: '1' },
        { label: 'Choice #2', value: '2' },
        { label: 'Choice #3', value: '3' }
    ]);

    const [scenario, setScenario] = useState({/*
        id: 1,
        name: "scenario title",
        game_id: 1,
        scenario_files: [
            {
                url: "SampleContent.jpg",
                name: "sample",
            }
        ],
        scenario_choices: [
            {
                "choice_id": 1,
                "scenario_id": 1,
                "content": "Sell stock"
            },
            {
                "choice_id": 3,
                "scenario_id": 3,
                "content": "Buy stock"
            },
            {
                "choice_id": 4,
                "scenario_id": 4,
                "content": "Hold position"
            },
            {
                "choice_id": 5,
                "scenario_id": 5,
                "content": "..."
            }
        ]
    */});

    const [messages, setMessages] = useState([]);
    const [lastOpenLen, setLastOpenLen] = useState(0);
    const [decisionMaking, setDecisionMaking] = useState(true);
    const [isPrimary, setIsPrimary] = useState(true);
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [showMessageModal, setShowMessageModal] = useState(false);
    const [showIndividualMessage, setShowIndividualMessage] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();
    const [currChoice, setCurChoice] = useState(null);
    const [messageUrl, setMessageUrl] = useState(null);
    const [messageContent, setMessageContent] = useState(null);
    const [scenarioUrl, setScenarioUrl] = useState(null);

    const fetchScenario = () => {
        fetch(`/api/player/instance/${location.state.instance}/role/${location.state.role}/scenario`,{
            method: 'GET',
            headers: { 'Content-Type': 'application/json' },
          })
          .then((response) => {
            if(!response.ok){
              throw new Error('Instance not found');
            }
            return response.json();
          })
          .then((data) => {
            //console.log(data);
            console.log(data);
            setIsPrimary(data.data.is_principal);
            setScenario(data.data.scenario);
            if(data.data.scenario.scenario_files.length > 0){
                setScenarioUrl(data.data.scenario.scenario_files[0].url);
            }
            let res = [];
            for(let i = 0; i < data.data.scenario.scenario_choices.length; i++){
                res.push({label: data.data.scenario.scenario_choices[i].content, value: `${data.data.scenario.scenario_choices[i].choice_id}`});
            }
            setOptions(res);
            if(res.length === 0){
                setDecisionMaking(false);
                setIsSubmitted(true);
            }else{
                setDecisionMaking(true);
            }
          })
          .catch(error => console.error('Error during fetch scenario: ', error));
    };

    const fetchMessages = () => {
        let role_id = location.state.role;
        fetch(`api/player/instance/${location.state.instance}/role/${role_id}/messages`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        })
        .then((response) => {
            if(!response.ok){
                throw new Error('Error');
            }
            return response.json();
        })
        .then((data) => {
            setMessages(data.data.messages)
        })
        .catch(error => console.error('Error during get messages: ', error));
    };

    const submit = () => {
        let role_id = location.state.role;
        let instance_id = location.state.instance;
        let scenario_id = scenario.id;
        let choice_id = currChoice;
        fetch(`/api/player/instance/${instance_id}/decision`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ scenario_id, choice_id, role_id})
          })
          .then((response) => {
            if(!response.ok){
              throw new Error('Error');
            }
            return response.json();
          })
          .then((data) => {
            console.log(data);
            alert(data.message);
            if(data.message === "Decision updated successfully" || data.message === "Decision saved successfully"){
                setIsSubmitted(true);
            }
          })
          .catch(error => console.error('Error during make decision: ', error));
    };

    const handleSelect = (selectedOption) => {
        setCurChoice(selectedOption.value);
        console.log("Selected option:", selectedOption);
    };

    const openMessages = () => {
        fetchMessages();

        setShowMessageModal(true);
    };

    const closeMessages = () => {
        setShowMessageModal(false);
    };

    const openIndividualMessage = (message) => {
        let url = null;
        let content = null;
        if(message.files.length > 0){
            url = message.files[0].url;
        }
        if(message.content != null){
            content = message.content;
        }
        setMessageUrl(url);
        setMessageContent(content);

        setShowIndividualMessage(true);
    };

    const closeIndividualMessage = () => {
        setShowIndividualMessage(false);
    };

    function PDFViewer({ pdfUrl }) {
        return (
            <object
                data={pdfUrl}
                type="application/pdf"
                width="100%"
                height="800px" // Increased height
            >
                <embed src={pdfUrl} width="100%" height="800px" /> {/* Increased height */}
                <p>This browser does not support PDFs. Please download the PDF to view it: <a href={pdfUrl}>Download PDF</a>.</p>
            </object>
        );
    }


    useEffect(() => {
        fetchScenario();

        let intervalId;
        let instance_id = location.state.instance; 
        const pollProceed = () => {
            fetch(`api/player/instance/${instance_id}/check`, {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' },
            })
            .then((response) => {
                if(!response.ok){
                    throw new Error('Error');
                  }
                return response.json()
            })
            .then((data) => {
                //console.log(data.data.is_ready);
                if(data.data.is_ready){
                    fetchScenario();
                    setIsSubmitted(false);
                }
                if(data.data.game_over){
                    navigate('/complete');
                }
            })
            .catch((error) => console.error('Error during ready polling: ', error));
        };

        pollProceed();

        intervalId = setInterval(pollProceed, POLLING_INTERVAL);

        return () => clearInterval(intervalId);
    }, []);

    return(
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
            <div className="messageBox" style={{position: 'absolute', top: '100px', right: '25px'}} onClick={openMessages}>
                <img src={"Mail.png"} alt="mail" height={50}/>
            </div>

            <br/><br/>

            <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', width: '70%'}}>
                {scenarioUrl != null ? (<PDFViewer pdfUrl={scenarioUrl}/>): (
                    <div></div>
                ) }
                
                
            </div>
            {
                //<!--https://github.com/LesenmiaoYu/ELCPDFs/blob/main/PS5%20CS%20360.pdf-->
                //<!--https://drive.google.com/file/d/1EflnYnszpmQgQ7KA2BRC8M2gjCWx1dCk/view?usp=drive_link-->
            }

            {isPrimary && decisionMaking ? (
                isSubmitted ? (
                    <div style={{
                        display: 'flex',
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        width: 'full',
                        marginTop: '40px',
                        marginBottom: '100px'
                    }}>
                        Choice Submitted. Awaiting Administrator...
                    </div>
                ) : (
                    <div style={{
                        display: 'flex',
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        width: 'full',
                        marginTop: '40px',
                        marginBottom: '100px'
                    }}>
                        <Dropdown options={options} placeholder="Select an option" onSelect={handleSelect}/>
                        <button className='SubmitButton' onClick={submit}>Submit</button>
                    </div>
                )) : (
                <div>
                    <br/><br/>
                </div>
            )
            }
            <Modal isOpen={showMessageModal} onClose={closeMessages}>
                <h1>Inbox</h1>
                <br/>
                {messages.map((message, index) => (
                    <div className="message" key={index} onClick={() => openIndividualMessage(message)}>
                        <h2>{message.content}</h2>
                    </div>
                ))}
            </Modal>
            <Modal isOpen={showIndividualMessage} onClose={closeIndividualMessage}>
                {messageUrl ? (
                    <div>
                        <h2>{messageContent}</h2>
                        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: '30px'}}>
                            <PDFViewer pdfUrl={messageUrl}/>
                        </div>
                        
                    </div>
                ):(
                    <div>
                        <h2>{messageContent}</h2>
                    </div>
                )}
            </Modal>
        </div>
    );
}

export default StudentInfoPage;