import React, { useEffect, useState } from 'react';
import {useNavigate} from 'react-router-dom';
import game_demo from '../Game_Demo1_Supply_Crisis.json';
import '.././Design.css';
import './Home.css'
import Modal from '../components/Modal';

function Home() {

  const navigate = useNavigate();
  const locationMapping = ['JFF ', 'JKP ', 'Zoom '];
  const longLocMapping = ['Fertitta Hall', 'Popovich Hall', 'Zoom']
  const roomMapping = [['A','B','C','D','E','F','G','J','K','L','M','N'],['A','B','C','D','E','F','G','J','K', '201A','201C','201D','201E','201F','201G'],[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]];

  const [instances, setInstances] = useState([]);
  const [roles, setRoles] = useState(game_demo.Role);
  const [available, setAvailable] = useState([]);
  const [showRoomModal, setShowRoomModal] = useState(false);
  const [selectRoleMessage, setSelectRoleMessage] = useState('');
  const [currRoom, setCurrRoom] = useState(null);

  const fetchInstances = () => {
    fetch('/api/player/instances', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    })
    .then((response) => {
      if(!response.ok) {
        throw new Error('No ongoing game instances found');
      }
      return response.json();
    })
    .then((data) => {
      console.log(data);
      setInstances(data.data.ongoing_instances);
    })
    .catch(error => console.error('Error during fetch instances: ', error));
  };

  const fetchRoles = (instance_id) => {
    fetch(`/api/player/instance/${instance_id}/roles`,{
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    })
    .then((response) => {
      if(!response.ok){
        throw new Error('Instance not found');
      }
      return response.json();
    })
    .then((data) => {
      console.log(data);
      setRoles(data);
    })
    .catch(error => console.error('Error during fetch roles: ', error));
  };

  // TODO: Need to discuss specifics of this API call
  const fetchAvailable = (instance_id) => { 
    fetch(`/api/player/instance/${instance_id}/roles/check`,{
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    })
    .then((response) => {
      if(!response.ok){
        throw new Error('Instance not found');
      }
      return response.json();
    })
    .then((data) => {
      setAvailable(data);
    })
    .catch(error => console.error('Error during fetch available roles: ', error));
  };

  const handleRoomClick = (id) => {
    fetchRoles(id);

    setCurrRoom(id);
    setShowRoomModal(true);
  };

  const closeRoomModal = () => {
    setCurrRoom(null);
    setShowRoomModal(false);
  };

  const selectRole = (instance_id, role_id) => {
    fetch(`/api/player/instance/${instance_id}/role/${role_id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    })
    .then((response) => {
      return response.json().then(data => ({status: response.status, data}));
    })
    .then((data) => {
      console.log(data);
      alert(data.data.message);
      if (data.status === 200){
        navigate('/studentinfo', {state: {instance: instance_id, role: role_id}});
      }
    })
    .catch(error => console.error('Error during select role: ', error));
  };

  useEffect(() => {
    fetchInstances();
  }, []);

  return (
    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', marginLeft: '10px', marginRight: '10px'}}>
      <h1 style={{marginTop: '30px'}}>Welcome to the ELC!</h1>
      {instances.length===0 ? (
          <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
            <br/>
            <h2>No Ongoing Games...</h2>
            <h2>Refresh the Page or Check Back Later</h2>
          </div>
        ) : 
        (
          <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', width: '80%'}}>
            <h2>Please select the room you are in to join</h2>
            <div className="rooms-container" style={{alignItems: 'center'}}>
                {instances.map((room, index) => (
                  <div className="room" key={index} onClick={() => handleRoomClick(room.instance_id)}>
                    <h2>{locationMapping[room.location_id - 1]} Room {roomMapping[room.location_id - 1][room.room_id-1]}</h2>
                    <div className="room-info">
                      Location: {longLocMapping[room.location_id - 1]} <br/>
                      Status: {room.state}
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}
        <Modal isOpen={showRoomModal} onClose={closeRoomModal}>
          <h1>Select Your Role</h1>
          <br/>
          {roles.map((role, index) => (
            <div className="role" key={index} onClick={() => selectRole(currRoom, role.id)}>
              <h2>{role.name} {role.mandatory ? ("(Mandatory)"):("")}</h2>
            </div>
          ))}
        </Modal>
    </div>
  );
}

export default Home;
