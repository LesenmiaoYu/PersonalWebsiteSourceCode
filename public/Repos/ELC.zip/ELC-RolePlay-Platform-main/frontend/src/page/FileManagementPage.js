import React, { useState, useEffect, useMemo } from 'react';
import "./FileManagementPage.css"
import FileDropdown from "../components/FileDropdown";
import ScenarioGraph from "../components/ScenarioGraph";
import "./EasterEgg.css"

const FileManagementPage = () => {

    const [terminatedData, setTerminatedData] = useState([]);
    const [selectedGame, setSelectedGame] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [amount, setAmount] = useState(12); // Default amount is 12
    const [easterEgg, setEasterEgg] = useState(false); // Easter Egg state

    const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTczMjE1Mzk1NywianRpIjoiNzg5Njg0OTgtZmQ2MC00MWNmLTk1MzUtMjRjMTk0MzBiOWNlIiwidHlwZSI6ImFjY2VzcyIsInN1YiI6InRyb2phbiIsIm5iZiI6MTczMjE1Mzk1NywiY3NyZiI6ImJlNjg3ZDk0LWNmMzAtNDllNC05ZTIyLWNmZTU4N2U5MDkzZiJ9._g5c7cuFYZ45AuWnPgiXpjysoqq0fhYtego-qO8ViGs";


    const fetchTerminatedGroups = (timeFrame = 12) => {
        const apiUrl = `/api/admin/game-instances/terminated/${timeFrame}`;
        console.log("Calling API:", apiUrl);

        fetch(apiUrl, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${localStorage.getItem('authToken')}`,
                'Content-Type': 'application/json',
            },
        })
            .then((response) => {
                if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
                return response.json();
            })
            .then((result) => {
                const gamesData = result.data?.games || [];
                const transformedGames = gamesData.map((game) => ({
                    game_id: game.game_id,
                    game_name: game.game_name,
                    instances: game.instances.map((instance) => ({
                        Room: instance.instance_id,
                        Traversed: instance.scenario_route || [],
                        location_name:instance.location_name
                    }))
                }));
                setTerminatedData(transformedGames);
                setLoading(false);

                if (timeFrame === 10) {
                    setEasterEgg(true);
                } else {
                    setEasterEgg(false);
                }
            })
            .catch((error) => {
                console.error('Error fetching data:', error);
                setLoading(false);
            });
    };

    const handleAmountChange = (e) => {
        const newAmount = parseInt(e.target.value, 10);
        if (!isNaN(newAmount) && newAmount > 0) {
            setAmount(newAmount);
            fetchTerminatedGroups(newAmount); // Fetch with the new amount
        }
    };

    const EasterEgg = () => (
        <div className="easter-egg">
            <h1>🎉 Surprise! 🎉</h1>
            <p>You’ve unlocked a special Easter egg!</p>
            <p>Hi Beth, this is team *10* sending in regards</p>
            <p> --Jason & David</p>
            <div className="fireworks">
                <div className="rocket"></div>
                <div className="rocket"></div>
                <div className="rocket"></div>
            </div>
        </div>
    );

    useEffect(() => {
        fetchTerminatedGroups(amount); // Fetch terminated groups once
    }, []); // Only run on component mount

    if (loading) return <p>Loading...</p>;
    if (error) return <p>{error}</p>;


    return (
        <div className="admin-management-container">


            <h1>Terminated Game Instances</h1>
            <br/>
            <label> Here you are seeing all the games that have been terminated in 12 hours by default</label>
            <br/>
            <div>
                <label htmlFor="amount">Alternatively:</label>
                <input
                    type="number"
                    id="amount"
                    value={amount}
                    onChange={handleAmountChange} // Call API on change
                    style={{marginLeft: '10px', width: '50px'}}
                />
                <span> hours</span>
            </div>
            <br/>

            {easterEgg && <EasterEgg />}

            <div className="scrollable-row">
                {terminatedData.map((game) => (
                    <div
                        className="group-box"
                        key={game.game_id}
                        onClick={() => setSelectedGame(game)} // Select the game
                    >
                        <h2>{game.game_name}</h2>
                        <div>{game.instances.location_name}</div>
                        <div className="group-info">
                            <span role="img" aria-label="terminated icon">✅</span>
                            <br/>
                            <div>{game.instances.length} room(s)</div>
                        </div>
                    </div>
                ))}
            </div>

            {selectedGame && (
                <div>
                    <h2>Selected Game: {selectedGame.game_name}</h2>
                    <ScenarioGraph
                        data={{
                            instances: selectedGame.instances.map(instance => ({
                                instance_id: instance.Room,
                                scenario_route: instance.Traversed,
                            }))
                        }}
                    />
                </div>
            )}
        </div>
    );
};

export default FileManagementPage;