import React, { useState, useEffect, useMemo } from 'react';
import '.././Design.css';
import './AdminManagementPage.css';
import FileDropdown from "../components/FileDropdown";
import Dropdown from "../components/Dropdown";
import ScenarioGraph from "../components/ScenarioGraph";

const POLLING_INTERVAL = 5000;

function AdminManagementPage() {
    const [groupsData, setGroupsData] = useState([]);
    //const [terminatedData, setTerminatedData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedGroup, setSelectedGroup] = useState(null);
    const [messageContent, setMessageContent] = useState('');
    const [toastMessage, setToastMessage] = useState(null);
    const [currMessageFile, setCurrMessageFile] = useState(null);
    const [selectedGroupOptions, setSelectedGroupOptions] = useState(null);
    const [currentRoleSelection, setCurrentRoleSelection] = useState(null);

    //const [selectedGame, setSelectedGame] = useState(null);

    const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTczMjE1Mzk1NywianRpIjoiNzg5Njg0OTgtZmQ2MC00MWNmLTk1MzUtMjRjMTk0MzBiOWNlIiwidHlwZSI6ImFjY2VzcyIsInN1YiI6InRyb2phbiIsIm5iZiI6MTczMjE1Mzk1NywiY3NyZiI6ImJlNjg3ZDk0LWNmMzAtNDllNC05ZTIyLWNmZTU4N2U5MDkzZiJ9._g5c7cuFYZ45AuWnPgiXpjysoqq0fhYtego-qO8ViGs";

    // const fetchTerminatedGroups= () => {
    //     fetch('/api/admin/game-instances/terminated/12', {
    //         method: 'GET',
    //         headers: {
    //             Authorization: `Bearer ${token}`,
    //             'Content-Type': 'application/json',
    //         },
    //     })
    //         .then((response) => {
    //             if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
    //             return response.json();
    //         })
    //         .then((result) => {
    //             const gamesData = result.data?.games || [];
    //             const transformedGames = gamesData.map((game) => ({
    //                 game_id: game.game_id,
    //                 instances: game.instances.map((instance) => ({
    //                     Room: instance.instance_id,
    //                     Traversed: instance.scenario_route || []
    //                 }))
    //             }));
    //             setTerminatedData(transformedGames);
    //             setLoading(false);
    //         })
    //         .catch((error) => {
    //             console.error('Error fetching data:', error);
    //             setLoading(false);
    //         });
    // };



    const fetchGroupData = () => {
        fetch('/api/admin/game-instances/check', {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${localStorage.getItem('authToken')}`,
                'Content-Type': 'application/json',
            },
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error(`HTTP Error: ${response.status}`);
                }
                return response.json();
            })
            .then((result) => {
                console.log('Fetched game data:', result);

                const instances = result.data?.instances || [];
                if (instances.length === 0) {
                    setError('No game instances found.');
                    setGroupsData([]);
                    setLoading(false);
                    return;
                }

                const data = instances.map((instance) => ({
                    instance_id: instance.instance_id,
                    gameName: instance.game_name,
                    roomName: instance.room,
                    location: instance.location,
                    readyStatus: instance.is_ready ? 'Ready' : 'Not Ready',
                    currentScenarioName: instance.current_scenario_name,
                    rolesInGame: instance.roles_in_game,
                    decisionMakingRound: instance.is_decision_round ? 'Yes' : 'No',
                    choicesMade: instance.decision_made || 'None',
                    // terminatedDate: instance.terminated_date (WE WILL CHANGE TO CREATED AT
                }));

                setGroupsData(data);
                setLoading(false);
            })
            .catch((err) => {
                console.error('Error fetching group data:', err);
                setError('Failed to fetch game data. Please try again.');
                setLoading(false);
            });
    };

    const proceedGameInstance = async (instance_id) => {
        try {
            const response = await fetch(`/api/admin/game-instance/${instance_id}/proceed`, {
                method: 'POST',
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('authToken')}`,
                    'Content-Type': 'application/json',
                },
            });

            const result = await response.json();
            if (response.ok) {
                showToast(result.message || 'Game instance proceeded successfully');
                fetchGroupData(); // Refresh data after proceeding
            } else {
                showToast(result.message || 'Failed to proceed game instance');
            }
        } catch (err) {
            console.error('Error proceeding game instance:', err);
            showToast('An error occurred while proceeding the game instance.');
        }
    };

    const sendMessage = (specRole) => {
        let content = null;
        if (messageContent) {
            content = messageContent;
        }
        let file_url = null;
        if (currMessageFile) {
            file_url = currMessageFile;
        }
        let instance_id = null;
        let myBody = null;
        if (selectedGroup) {
            instance_id = selectedGroup.instance_id;
            if (specRole !== null) {
                let role_id = specRole;
                myBody = { content, file_url, instance_id, role_id };
            } else {
                myBody = { content, file_url, instance_id };
            }
        } else {
            myBody = { content, file_url };
        }
        console.log(myBody);
        fetch(`/api/admin/message`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${localStorage.getItem('authToken')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(myBody)
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Error');
                }
                return response.json();
            })
            .then((data) => {
                showToast(data.message);
            })
            .catch((error) => console.error('Error during send message: ', error));
    };

    const showToast = (message) => {
        setToastMessage(message);
        setTimeout(() => setToastMessage(null), 3000); // Automatically hide after 3 seconds
    };

    const changeOptions = (rolesInGame) => {
        let options = [];
        options.push({ label: 'Send to all roles', value: null });
        for (let i = 0; i < rolesInGame.length; i++) {
            let curr = { label: rolesInGame[i].name, value: rolesInGame[i].id }
            options.push(curr);
        }
        setSelectedGroupOptions(options);
    };

    useEffect(() => {
        //fetchTerminatedGroups();

        let intervalId;

        // Function to poll for updates
        const pollData = () => {
            fetchGroupData();
        };

        pollData(); // Initial fetch
        intervalId = setInterval(pollData, POLLING_INTERVAL);

        return () => clearInterval(intervalId); // Cleanup on unmount
    }, []);

    // const memoizedGraphData = useMemo(() => {
    //     if (!selectedGame) return null;
    //
    //     return {
    //         instances: selectedGame.instances.map(instance => ({
    //             instance_id: instance.Room,
    //             scenario_route: instance.Traversed,
    //         }))
    //     };
    // }, [selectedGame]); // Only re-compute when selectedGame changes

    if (loading) return <p>Loading...</p>;
    if (error) return <p>{error}</p>;

    // const ongoingInstances = instances.filter((inst) => inst.state === "ongoing");
    // const terminatedInstances = instances.filter((inst) => inst.state === "terminated");


    const handleUploadFile = () => {
        const fileInput = document.getElementById("fileInput");
        const file = fileInput.files[0];

        if (file) {
            const formData = new FormData();
            formData.append('file', file); // Append the file

            // First API call to upload the file
            fetch(`/api/upload_file`, {
                method: 'POST',
                body: formData,
            })
                .then(response => {
                    if (response.ok) {
                        return response.json(); // Convert the response to JSON if successful
                    }
                    throw new Error('Network response was not ok.'); // Handle errors
                })
                .then(data => {
                    console.log('File URL:', data.url);
                    // Prepare the body for the second API call
                    /*const messageBody = JSON.stringify({
                        content: "You have received a new file to view.",
                        message_files: [data.url]
                    });*/
                    setCurrMessageFile(data.url);

                    // Second API call to send the message with the file URL
                    /*return fetch('/api/admin/message', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTczMjE3MTY1MywianRpIjoiZmEzNTZjZTUtOGFhMi00NGJmLWJmNmUtMzI0YzgwNGFkYjI0IiwidHlwZSI6ImFjY2VzcyIsInN1YiI6InRyb2phbiIsIm5iZiI6MTczMjE3MTY1MywiY3NyZiI6Ijc0MDY4ZmYzLWYwNzEtNGY1Ny04YzlhLTI0MzFlMzMyMmRjNiJ9.fJ2il6LwZEPZns0oWOnmHsb6wNNIDOnusSI6auMK4G4'
                        },
                        body: messageBody
                    });*/
                })/*
                .then(response => {
                    if (response.ok) {
                        return response.json(); // Handle the JSON response
                    }
                    throw new Error('Failed to send admin message.');
                })
                .then(data => {
                    console.log('Message sent successfully:', data);
                })*/
                .catch(error => {
                    console.error('Error:', error); // Handle any errors
                });

        } else {
            alert("Please select a file to upload.");
        }
    };


    return (
        <div className="admin-management-container">
            <h1>Ongoing Game Instances</h1>
            <div className="scrollable-row">
                {groupsData

                    .map((group) => (
                        <div
                            className="group-box"
                            key={group.instance_id}
                            onClick={() => { setSelectedGroup(group); changeOptions(group.rolesInGame) }}
                        >
                            <h2>{group.gameName}</h2>
                            <div className="group-info">
                                <span role="img" aria-label="group icon">👥</span>
                                <p>Room: {group.location + " " + group.roomName}</p>
                                <p>Ready: {group.readyStatus}</p>
                            </div>
                        </div>
                    ))}
            </div>

            <br /><br />

            {/*<h1>Terminated Game Instances</h1>*/}
            {/*<div className="scrollable-row">*/}
            {/*    {terminatedData.map((game) => (*/}
            {/*        <div*/}
            {/*            className="group-box"*/}
            {/*            key={game.game_id}*/}
            {/*            onClick={() => setSelectedGame(game)} // Set selected game for ScenarioGraph*/}
            {/*        >*/}
            {/*            <h2>Game ID: {game.game_id}</h2>*/}
            {/*            <div className="group-info">*/}
            {/*                <span role="img" aria-label="terminated icon">📅: 3 hours</span>*/}
            {/*                <br/>*/}
            {/*                <div> Instances: {game.instances.length}</div>*/}
            {/*            </div>*/}
            {/*        </div>*/}
            {/*    ))}*/}
            {/*</div>*/}

            {/*{selectedGame && (*/}
            {/*    <div className="modal">*/}
            {/*        <div className="modal-content">*/}
            {/*            <button className="close-button" onClick={() => setSelectedGame(null)}>✖</button>*/}
            {/*            <h2>Game ID: {selectedGame.game_id}</h2>*/}
            {/*            /!* Render the ScenarioGraph component *!/*/}
            {/*            {console.log("here at modal", selectedGame.instances)}*/}
            {/*            <ScenarioGraph data={memoizedGraphData} />*/}

            {/*        </div>*/}
            {/*    </div>*/}
            {/*)}*/}

            {selectedGroup && (
                <div className="modal">
                    <div className="modal-content">
                        <button className="close-button" onClick={() => setSelectedGroup(null)}>✖</button>
                        <h2>{selectedGroup.gameName}</h2>
                        <p>Room: {selectedGroup.roomName}</p>
                        <p>Location: {selectedGroup.location}</p>
                        <p>Current Scenario: {selectedGroup.currentScenarioName}</p>
                        <p>Decision Round: {selectedGroup.decisionMakingRound}</p>
                        <p>Choices Made: {selectedGroup.choicesMade}</p>
                        <p>Roles In Game: {(selectedGroup.rolesInGame.map(role => role.name)).join(', ')}</p>

                        <br />
                        Message:
                        <div style={{ border: '1px solid', borderRadius: '10px', padding: '10px', marginTop: '5px' }}>
                            <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', width: '320px', height: '50px' }}>
                                Specify Role?
                                <Dropdown
                                    options={selectedGroupOptions}
                                    def={{ label: 'Send to all roles', value: null }}
                                    placeholder='Select Role'
                                    onSelect={(option) => setCurrentRoleSelection(option.value)}
                                />
                            </div>
                            <br />
                            <textarea
                                className="message-box"
                                placeholder="Enter your message"
                                value={messageContent}
                                onChange={(e) => setMessageContent(e.target.value)}
                            ></textarea>

                            <input type="file" id="fileInput" />
                            <button className="edit-button" onClick={handleUploadFile}>
                                Upload
                            </button>
                        </div>


                        <button
                            className="send-button"
                            onClick={() => sendMessage(currentRoleSelection)}
                        >
                            Send Message
                        </button>
                        <br /><br />
                        <button
                            className="proceed-button"
                            onClick={() => proceedGameInstance(selectedGroup.instance_id)}
                        >
                            Proceed Game
                        </button>
                    </div>
                </div>
            )
                //if we are on the last scenario, we provide terminate
            }

            {toastMessage && (
                <div className="toast">
                    {toastMessage}
                </div>
            )}
        </div>
    );
}

export default AdminManagementPage;