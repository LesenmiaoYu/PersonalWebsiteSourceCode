import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import './Header.css'; // Ensure this path is correct

function Header() {
    const location = useLocation();
    const navigate = useNavigate();

    const headerPaths = {"/bm": "M", "/setup": "M", "/management": "M", "/filemanagement": 'M', "/": 'S', "/complete": "S", "/studentinfo": "S"}


    const logout = () => {
        localStorage.removeItem('authToken');
        navigate('/bm');
    };

    return (
        <div className='Header'>
            <div className="left-placeholder"></div>
            <Link to="/" className="header-logo">
                <img src={"MarshallLogo.png"} alt="Marshall Logo" height={75} />
            </Link>
            {headerPaths[location.pathname] === "M" ? (
                <div className="header-links">
                    <Link to="/bm" className="header-link">Login</Link>
                    <Link to="/setup" className="header-link">Setup</Link>
                    <Link to="/management" className="header-link">Ongoing</Link>
                    <Link to="/filemanagement" className="header-link">Terminated</Link>
                    <div onClick={logout} className="text-button">Logout</div>
                </div>
            ) : (
                <div></div>
            )}
        </div>
    );
}

export default Header;
