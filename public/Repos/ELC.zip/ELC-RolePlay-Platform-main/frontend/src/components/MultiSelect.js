import React from 'react';
import './MultiSelect.css';

function MultiSelect({ options, selectedValues, onSelectionChange }) {
    const toggleSelection = (value) => {
        if (selectedValues.includes(value)) {
            onSelectionChange(selectedValues.filter(item => item !== value));
        } else {
            onSelectionChange([...selectedValues, value]);
        }
    };

    return (
        <div>
            <div className="checkbox-container">
                {options.map(option => (
                    <label key={option.value} className="checkbox-label">
                        <input
                            type="checkbox"
                            checked={selectedValues.includes(option.value)}
                            onChange={() => toggleSelection(option.value)}
                        />
                        {option.label}
                    </label>
                ))}
            </div>
            <p>Selected Rooms: {selectedValues.length}</p>
        </div>
    );
}
export default MultiSelect;
