import React, { useState } from "react";
import "./FileDropdown.css"

// Mock data for files in storage
const mockFiles = [
    { id: 1, name: "BlackCatWinery_Scenario2_CEO" },
    { id: 2, name: "BlackCatWinery_Scenario3_CEO" },
    { id: 3, name: "BlackCatWinery_Scenario3_CFO" },
    { id: 4, name: "TrojanMotor_Scenario2_Intern" },
];

const FileDropdown = () => {
    const [isOpen, setIsOpen] = useState(false); // Dropdown open/close state
    const [files, setFiles] = useState([]); // Fetched files (mocked)
    const [searchText, setSearchText] = useState(""); // Search text for filtering
    const [selectedFile, setSelectedFile] = useState(null); // Selected file

    // Simulate fetching files from storage
    const fetchFiles = () => {
        setFiles(mockFiles); // Set the mock files
        setIsOpen((prev) => !prev); // Toggle the dropdown
    };

    // Handle file selection
    const handleFileSelect = (file) => {
        setSelectedFile(file);
    };

    // Filter files based on search text
    const filteredFiles = files.filter((file) =>
        file.name.toLowerCase().includes(searchText.toLowerCase())
    );

    // Handle send button click
    const handleSend = () => {
        if (selectedFile) {
            alert(`Sending file: ${selectedFile.name}`);
        } else {
            alert("Please select a file to send.");
        }
    };

    return (
        <div className="file-dropdown">
            {/* Dropdown Trigger */}
            <button className="dropdown-toggle" onClick={fetchFiles}>
                {isOpen ? "Close" : "Select a File"}
            </button>

            {/* Dropdown Menu */}
            {isOpen && (
                <div className="dropdown-menu">
                    {/* Search Bar */}
                    <input
                        type="text"
                        className="dropdown-search-bar"
                        placeholder="Search files..."
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                    />
                    {/* File List */}
                    {filteredFiles.length > 0 ? (
                        filteredFiles.map((file) => (
                            <div
                                key={file.id}
                                className={`dropdown-item ${
                                    selectedFile?.id === file.id ? "selected" : ""
                                }`}
                                onClick={() => handleFileSelect(file)}
                            >
                                {file.name}
                            </div>
                        ))
                    ) : (
                        <div className="dropdown-item">No files match your search.</div>
                    )}
                </div>
            )}

            {/* Selected File and Send Button */}
            {selectedFile && (
                <div className="file-actions">
                    <p>Selected File: {selectedFile.name}</p>
                    <button className="send-button" onClick={handleSend}>
                        Send
                    </button>
                </div>
            )}
        </div>
    );
};

export default FileDropdown;