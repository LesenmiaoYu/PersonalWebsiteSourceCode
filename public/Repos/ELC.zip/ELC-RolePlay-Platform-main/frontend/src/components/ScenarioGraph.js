import React, { useEffect, useRef } from 'react';
import { ForceGraph2D } from 'react-force-graph';

function ScenarioGraph({ data }) {
    const fgRef = useRef();

    useEffect(() => {
        // Disable forces so nodes remain in initial positions but still draggable
        if (fgRef.current) {
            fgRef.current.d3Force('charge', null);
            fgRef.current.d3Force('center', null);
        }
    }, []);

    // Ensure valid data structure
    if (!data || !data.instances) {
        return <p>No data available for the graph.</p>;
    }

    console.log("clicked", data);

    // Extract unique nodes and sort them
    const allTraversed = data.instances.flatMap(inst => inst.scenario_route);
    const uniqueNodes = [...new Set(allTraversed)].sort((a, b) => a - b);

    // Create nodes with initial positions
    const spacing = 100;
    const startY = -(uniqueNodes.length - 1) * (spacing / 2);
    const nodes = uniqueNodes.map((nodeId, i) => ({
        id: nodeId.toString(),
        name: `Scenario ${nodeId}`,
        x: 0,
        y: startY + i * spacing
    }));

    // Build a map of link frequencies
    const linkMap = {};
    data.instances.forEach(inst => {
        const path = inst.scenario_route;
        for (let i = 0; i < path.length - 1; i++) {
            const source = path[i];
            const target = path[i + 1];
            const key = `${source}-${target}`;
            if (!linkMap[key]) {
                linkMap[key] = 0;
            }
            linkMap[key] += 1;
        }
    });

    // Create links
    const links = Object.entries(linkMap).map(([key, value]) => {
        const [source, target] = key.split('-');
        return { source: source.toString(), target: target.toString(), value };
    });

    return (
        <ForceGraph2D
            ref={fgRef}
            graphData={{ nodes, links }}
            nodeLabel={null} // We'll draw labels ourselves
            linkDirectionalParticles="value"
            linkDirectionalParticleWidth={link => link.value}
            width={1400}
            height={600}
            enableNodeDrag={true}
            // Draw nodes as circles + labels
            nodeCanvasObjectMode={() => 'replace'}
            nodeCanvasObject={(node, ctx, globalScale) => {
                const radius = 8;
                // Draw circle
                ctx.beginPath();
                ctx.arc(node.x, node.y, radius, 0, 2 * Math.PI, false);
                ctx.fillStyle = 'lightblue';
                ctx.fill();
                ctx.strokeStyle = 'darkblue';
                ctx.stroke();

                // Draw label
                const label = node.name;
                const fontSize = 12 / globalScale;
                ctx.font = `${fontSize}px Sans-Serif`;
                ctx.fillStyle = 'black';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(label, node.x, node.y - radius - (fontSize + 2));
            }}
            // Draw link weights at midpoint
            linkCanvasObjectMode={() => 'after'}
            linkCanvasObject={(link, ctx, globalScale) => {
                const label = link.value.toString();
                const fontSize = 10 / globalScale;
                ctx.font = `${fontSize}px Sans-Serif`;
                ctx.fillStyle = 'red';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                const start = link.source;
                const end = link.target;
                // Midpoint of the link
                const midX = (start.x + end.x) / 2;
                const midY = (start.y + end.y) / 2;
                ctx.fillText(label, midX, midY);
            }}
        />
    );
}

export default ScenarioGraph;
