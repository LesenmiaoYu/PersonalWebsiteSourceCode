import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './page/Home';
import ManagerLogin from './page/ManagerLogin';
import AdminSetupPage from './page/AdminSetupPage';
import AdminManagementPage from "./page/AdminManagementPage";
import StudentFinishedPage from './page/StudentFinishedPage';
import Header from "./components/Header";
import StudentInfoPage from './page/StudentInfoPage';
import FileManagementPage from './page/FileManagementPage';


function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/bm" element={<ManagerLogin />} />
        <Route path="/setup" element={<AdminSetupPage />} />
        <Route path="/management" element={<AdminManagementPage />} />
        <Route path="/complete" element={<StudentFinishedPage />} />
        <Route path="/studentinfo" element={<StudentInfoPage />} />
          <Route path="/filemanagement" element={<FileManagementPage />} />
      </Routes>
    </Router>
  );
}

export default App;
