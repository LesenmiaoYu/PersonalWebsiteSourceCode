# ELC-RolePlay-Platform

# Project Overview
- **Backend**: Flask (Python)
- **Frontend**: React (JS)
- **Database**: MySQL

## Prerequisites

Before setting up the project, make sure that you have Docker installed:

- **Docker**: [Download and Install Docker](https://docs.docker.com/get-docker/)
- **Docker Compose**: Comes bundled with Docker Desktop on Windows/macOS


## Project Directory Structure
```angular2html
ELC-RolePlay-Platform/
├── backend/
│   ├── app.py
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── 
│   │   ├── Home.js
│   │   └── ManagerLogin.js
|   ├── App.js
│   ├── package.json
│   ├── package-lock.json
│   └── Dockerfile
├── db/
│   └── init.sql
├── .gitignore
├── docker-compose.yml
└── README.md

```

## Installation and Setup

Follow these steps to set up and run the application:

### 1. Clone the Repository

```bash
> mkdir CSCI401 && cd CSCI401
> git clone git@github.com:sssaang/ELC-RolePlay-Platform.git
> cd ELC-RolePlay-Platform
```

### 2. In the root directory, run docker command
```bash
> docker-compose up --build
```

### 3. When you want to clean containers along with the volumes run the following docker command
```bash
> docker-compose down -v
```
