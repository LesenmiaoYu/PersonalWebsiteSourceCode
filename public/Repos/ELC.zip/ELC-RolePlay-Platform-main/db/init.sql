-- Table: manager
CREATE TABLE IF NOT EXISTS manager (
  id VARCHAR(255) PRIMARY KEY,
  pw VARCHAR(255) NOT NULL
);

-- Table: role
CREATE TABLE IF NOT EXISTS role (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  game_id INTEGER NOT NULL,
  mandatory BOOLEAN,
  principal BOOLEAN
);

-- Table: location
CREATE TABLE IF NOT EXISTS location (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255)
);

-- Table: room
CREATE TABLE IF NOT EXISTS room (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  location_id INTEGER
);

-- Table: game
CREATE TABLE IF NOT EXISTS game (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255)
);

-- Table: scenario
CREATE TABLE IF NOT EXISTS scenario (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  game_id INTEGER,
  first_scenario BOOLEAN,
  number INTEGER
);

-- Table: scenario_files
CREATE TABLE IF NOT EXISTS scenario_file (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  scenario_id INTEGER,
  url VARCHAR(255)
);

-- Table: scenario_choices
CREATE TABLE IF NOT EXISTS scenario_choice (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  scenario_id INTEGER,
  content TEXT
);

-- Table: scenario_decision_mapping
CREATE TABLE IF NOT EXISTS scenario_decision_mapping (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  from_scenario INTEGER,
  to_scenario INTEGER,
  choice_id INTEGER
);

-- Table: scenario_decision
CREATE TABLE IF NOT EXISTS scenario_decision (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  instance_id INTEGER,
  scenario_id INTEGER,
  choice_id INTEGER
);

-- Table: game_instance
CREATE TABLE IF NOT EXISTS game_instance (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  game_id INTEGER,
  location_id INTEGER,
  room_id INTEGER,
  scenario_id INTEGER,
  state VARCHAR(255),
  created_at TIMESTAMP NULL DEFAULT NULL,
  started_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NULL DEFAULT NULL
);

-- Table: message
CREATE TABLE IF NOT EXISTS message (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  game_instance_id INTEGER,
  content TEXT NOT NULL,
  role_id INTEGER,
  FOREIGN KEY (game_instance_id) REFERENCES game_instance(id),
  FOREIGN KEY (role_id) REFERENCES role(id)
);

-- Table: message_file
CREATE TABLE IF NOT EXISTS message_file (
  id INTEGER AUTO_INCREMENT PRIMARY KEY,
  message_id INTEGER,
  url VARCHAR(255),
  FOREIGN KEY (message_id) REFERENCES message(id)
);

-- Table: role_instance
CREATE TABLE IF NOT EXISTS role_instance (
  instance_id INTEGER,
  role_id INTEGER,
  PRIMARY KEY (instance_id, role_id)
);

-- Table: instance_status
CREATE TABLE IF NOT EXISTS instance_status (
  instance_id INTEGER PRIMARY KEY,
  current_scenario_id INTEGER,
  next_scenario_id INTEGER
);
