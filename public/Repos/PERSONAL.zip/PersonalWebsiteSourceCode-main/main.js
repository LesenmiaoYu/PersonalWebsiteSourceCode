import './style.css'
import Experience from'./Experience/Experience'

const experience = new Experience(document.querySelector(".experience-canvas"));

