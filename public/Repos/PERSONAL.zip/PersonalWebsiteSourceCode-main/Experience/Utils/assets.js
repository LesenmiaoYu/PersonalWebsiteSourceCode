export default [
    {
        name: "room",
        type: "glbModel",
        path: "/models/myRoomTall.glb",
    },
];