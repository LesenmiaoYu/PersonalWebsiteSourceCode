package com.project.eat.eatbackend;

public class MenuItemServiceForGuest {
    
}
